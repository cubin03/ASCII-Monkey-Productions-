/* Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above notice and this permission notice shall be included in all copies
 * or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

/*Author: Ian Cubin
**Date:   04/22/12
**External Resources: NeHe Productions && OpenGL Tutorial
*
*
**Description: This example implements Fog using three different filters. 
*              Fog density && Fog start/end modifable based on user input.
*/

#include <iostream>
#include <stdlib.h>

#ifdef __APPLE__
#include <OpenGL/OpenGL.h>
#include <GLUT/glut.h>
#else
#include <GL/glut.h>
#endif

#include "imageloader.h" //Provided thanks to OpenGL tutorial

using namespace std;

float      _angle = 0;            //The rotation of the box
GLuint     _textureId;            //The id of the cube texture
GLuint     _textureId2;           //The id of the background texture
GLint      fogFilter = GL_LINEAR; //The OpenGL value of the fog's filter
float	   fogDensity = 0.05f;    //The density of the fog (only applies to GL_EXP && GL_EXP2 fog filter)
float      xMotion = 0.0f;        //The translation of the camera (x-axis)
float      zMotion = 0.0f;        //The translation of the camera (y-axis)
float      cRotation = 0.0f;      //The rotation of the camera
int        adaptBackground = 0;   //The scale for the background
float	   fogStart = 0.0f;       //The start point of fog (where the least amount of fog is applied)
float	   fogEnd = 30.0f;        //The end point of fog (beyond this value all objects become 100% gray)
int        fogToggle = 0;         //Toggles fog on/off


const float BOX_SIZE = 7.0f;      //The length of each side of the cube

//Forward declarations
//////////////////////
void loadCubes();
void loadBackground();
//////////////////////

//Handles all user input
void handleKeypress(unsigned char key, int x, int y) 
{
	switch (key) 
	{
		//Changes the fog filter being applied
		case 102: // 'f' key
			if(fogFilter == GL_LINEAR)
			{
				fogFilter = GL_EXP;
			}
			else if(fogFilter == GL_EXP)
			{
				fogFilter = GL_EXP2;
			}
			else
			{
				fogFilter = GL_LINEAR;
			}
			break;

		//Changes the fog density (only affects fog using GL_EXP || GL_EXP2 filter)
		case 43: // '+' key
			if(fogDensity < 0.1f)
			{
				fogDensity += 0.001f;
			}
			break;
		case 45: // '-' key
			if(fogDensity > 0.0f)
			{
				fogDensity -= 0.001f;
			}
			break;

		//Translates the cubes across the z-axis
		case 97: // 'a' key
			xMotion++;
			break;
		case 100: // 'd' key
			xMotion--;
			break;
		case 119: // 'w' key
			zMotion--;
			adaptBackground++;
			break;
		case 115: // 's' key
			zMotion++;
			adaptBackground--;
			break;

		//Changes linear start/end point of fog (only affects fog using GL_LINEAR filter)
		case 99: // 'c' key
			fogEnd++;
			if(fogEnd > 200.0f)
			{
				fogEnd = 200.0f;
			}
			break;
		case 118: // 'v' key
			fogEnd--;
			if(fogEnd < 0.0f)
			{
				fogEnd = 0.0f;
			}
			break;

		//Enables/diables 
		case 110:
			if(fogToggle == 0)
			{
				glDisable(GL_FOG);
				fogToggle++;
			}
			else
			{
				glEnable(GL_FOG);
				fogToggle = 0;
			}
			break;

		//Close program
		case 27: //Escape key
			exit(0);
	}
}

//Makes the image into a texture, and returns the id of the texture
//Provided thanks to OpenGL tutorial
GLuint loadTexture(Image* image) 
{
	GLuint textureId;
	glGenTextures(1, &textureId);
	glBindTexture(GL_TEXTURE_2D, textureId);
	glTexImage2D(GL_TEXTURE_2D,
				 0,
				 GL_RGB,
				 image->width, image->height,
				 0,
				 GL_RGB,
				 GL_UNSIGNED_BYTE,
				 image->pixels);
	return textureId;
}

//Setup render calls and load images
void initRendering() 
{
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0);
	glEnable(GL_NORMALIZE);
	glEnable(GL_COLOR_MATERIAL);
	glEnable(GL_FOG);                   //Enable fog on scene
	glClearColor(0.5f, 0.5f, 0.5f, 1);
	
	//Load cube texture
	Image* image = loadBMP("Stonewall15_512x512.bmp");
	_textureId = loadTexture(image);
	delete image;

	//Load background texture
	image = loadBMP("skyrender0001.bmp");
	_textureId2 = loadTexture(image);
	delete image;
}

//Handles the viewport and projection matrix of the window
void handleResize(int w, int h) 
{
	glViewport(0, 0, w, h);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(45.0, (float)w / (float)h, 1.0, 200.0);
}

//Render the scene
void drawScene() 
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	
	////////////////////////////////////////////////
	//Fog starts here
	GLfloat fogColor[] = {0.5f, 0.5f, 0.5f, 1};
	glFogfv(GL_FOG_COLOR, fogColor);
	glFogi(GL_FOG_MODE, fogFilter);
	glFogf(GL_FOG_START, fogStart);
	glFogf(GL_FOG_END, fogEnd);
	glFogf(GL_FOG_DENSITY, fogDensity);
	//End fog
	////////////////////////////////////////////////

	//Create an ambient light
	GLfloat ambientLight[] = {0.3f, 0.3f, 0.3f, 1.0f};
	glLightModelfv(GL_LIGHT_MODEL_AMBIENT, ambientLight);
	
	GLfloat lightColor[] = {0.7f, 0.7f, 0.7f, 1.0f};
	GLfloat lightPos[] = {-2 * BOX_SIZE, BOX_SIZE, 4 * BOX_SIZE, 1.0f}; //Position light 
	glLightfv(GL_LIGHT0, GL_DIFFUSE, lightColor);
	glLightfv(GL_LIGHT0, GL_POSITION, lightPos);

	//Enable and declare texture properties
	glEnable(GL_TEXTURE_2D);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glColor3f(1.0f, 1.0f, 1.0f);

	////////////////////////////////////////////////////////////////////////

	glBindTexture(GL_TEXTURE_2D, _textureId2); //Set background texture id

	//Render Background
	glTranslatef(0.0, 0.0f, zMotion-60.0f);
	glRotatef(0, 0.0f, 0.0f, 0.0f);
	glBegin(GL_QUADS);
	loadBackground();
	glEnd();

	//Resets matrices
	glLoadIdentity();

	glBindTexture(GL_TEXTURE_2D, _textureId); //Switch texture id to cube texture id

	//Render first cube
	glTranslatef(xMotion-10.0f, 0.0f, zMotion-20.0f);
	glRotatef(-_angle, 1.0f, 1.0f, 0.0f);
	glBegin(GL_QUADS);
	loadCubes();
	glEnd();

	glLoadIdentity(); //Reset

	//Render second cube
	glTranslatef(xMotion, 0.0f, zMotion-30.0f);
	glRotatef(_angle, 1.0f, 1.0f, 0.0f);
	glBegin(GL_QUADS);
	loadCubes();
	glEnd();

	glLoadIdentity(); //Reset

	//Render third cube
	glTranslatef(xMotion+10.0f, 0.0f, zMotion-40.0f);
	glRotatef(-_angle, 1.0f, 1.0f, 0.0f);
	glBegin(GL_QUADS);
	loadCubes();
	glEnd();

	glLoadIdentity(); //Reset

	//Render fourth cube
	glTranslatef(xMotion+20.0f, 0.0f, zMotion-50.0f);
	glRotatef(_angle, 1.0f, 1.0f, 0.0f);
	glBegin(GL_QUADS);
	loadCubes();
	glEnd();
	
	glutSwapBuffers();
}

//Called every 25 milliseconds
void update(int value) 
{
	//Updates angle used to spin cubes
	_angle += 1.0f;
	if (_angle > 360) 
	{
		_angle -= 360;
	}
	glutPostRedisplay();
	glutTimerFunc(25, update, 0);
}

int main(int argc, char** argv) 
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
	glutInitWindowSize(1280, 720);
	
	glutCreateWindow("Fog");

	initRendering();
	
	glutDisplayFunc(drawScene);
	glutKeyboardFunc(handleKeypress);
	glutReshapeFunc(handleResize);
	glutTimerFunc(25, update, 0);
	
	glutMainLoop();
	return 0;
}

//Creates the cubes vertices and texture coordinates
void loadCubes()
{
	//////////////////////////////////////////////////////////////

	//Top face
	glNormal3f(0.0, 1.0f, 0.0f);
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(-BOX_SIZE / 2, BOX_SIZE / 2, -BOX_SIZE / 2);
	glTexCoord2f(1.0f, 0.0f);
	glVertex3f(-BOX_SIZE / 2, BOX_SIZE / 2, BOX_SIZE / 2);
	glTexCoord2f(1.0f, 1.0f);
	glVertex3f(BOX_SIZE / 2, BOX_SIZE / 2, BOX_SIZE / 2);
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(BOX_SIZE / 2, BOX_SIZE / 2, -BOX_SIZE / 2);

	//Bottom face
	glNormal3f(0.0, -1.0f, 0.0f);
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(-BOX_SIZE / 2, -BOX_SIZE / 2, -BOX_SIZE / 2);
	glTexCoord2f(1.0f, 0.0f);
	glVertex3f(BOX_SIZE / 2, -BOX_SIZE / 2, -BOX_SIZE / 2);
	glTexCoord2f(1.0f, 1.0f);
	glVertex3f(BOX_SIZE / 2, -BOX_SIZE / 2, BOX_SIZE / 2);
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(-BOX_SIZE / 2, -BOX_SIZE / 2, BOX_SIZE / 2);
	
	//Front face
	glNormal3f(0.0, 0.0f, 1.0f);
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(-BOX_SIZE / 2, -BOX_SIZE / 2, BOX_SIZE / 2);
	glTexCoord2f(1.0f, 0.0f);
	glVertex3f(BOX_SIZE / 2, -BOX_SIZE / 2, BOX_SIZE / 2);
	glTexCoord2f(1.0f, 1.0f);
	glVertex3f(BOX_SIZE / 2, BOX_SIZE / 2, BOX_SIZE / 2);
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(-BOX_SIZE / 2, BOX_SIZE / 2, BOX_SIZE / 2);
	
	//Back face
	glNormal3f(0.0, 0.0f, -1.0f);
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(-BOX_SIZE / 2, -BOX_SIZE / 2, -BOX_SIZE / 2);
	glTexCoord2f(1.0f, 0.0f);
	glVertex3f(-BOX_SIZE / 2, BOX_SIZE / 2, -BOX_SIZE / 2);
	glTexCoord2f(1.0f, 1.0f);
	glVertex3f(BOX_SIZE / 2, BOX_SIZE / 2, -BOX_SIZE / 2);
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(BOX_SIZE / 2, -BOX_SIZE / 2, -BOX_SIZE / 2);

	//Left face
	glNormal3f(-1.0, 0.0f, 0.0f);
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(-BOX_SIZE / 2, -BOX_SIZE / 2, -BOX_SIZE / 2);
	glTexCoord2f(1.0f, 0.0f);
	glVertex3f(-BOX_SIZE / 2, -BOX_SIZE / 2, BOX_SIZE / 2);
	glTexCoord2f(1.0f, 1.0f);
	glVertex3f(-BOX_SIZE / 2, BOX_SIZE / 2, BOX_SIZE / 2);
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(-BOX_SIZE / 2, BOX_SIZE / 2, -BOX_SIZE / 2);

	//Right face
	glNormal3f(1.0, 0.0f, 0.0f);
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(BOX_SIZE / 2, -BOX_SIZE / 2, -BOX_SIZE / 2);
	glTexCoord2f(1.0f, 0.0f);
	glVertex3f(BOX_SIZE / 2, BOX_SIZE / 2, -BOX_SIZE / 2);
	glTexCoord2f(1.0f, 1.0f);
	glVertex3f(BOX_SIZE / 2, BOX_SIZE / 2, BOX_SIZE / 2);
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(BOX_SIZE / 2, -BOX_SIZE / 2, BOX_SIZE / 2);
	//////////////////////////////////////////////////////////////
}

//Creates the background vertices and texture coordinates
void loadBackground()
{
	//Front face
	glNormal3f(0.0, 0.0f, 1.0f);
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(-BOX_SIZE*(6+adaptBackground), -BOX_SIZE*(4+adaptBackground), BOX_SIZE);
	glTexCoord2f(1.0f, 0.0f);
	glVertex3f(BOX_SIZE*(6+adaptBackground), -BOX_SIZE*(4+adaptBackground), BOX_SIZE);
	glTexCoord2f(1.0f, 1.0f);
	glVertex3f(BOX_SIZE*(6+adaptBackground), BOX_SIZE*(4+adaptBackground), BOX_SIZE);
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(-BOX_SIZE*(6+adaptBackground), BOX_SIZE*(4+adaptBackground), BOX_SIZE);
}









