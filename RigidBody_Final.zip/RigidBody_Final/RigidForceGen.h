#pragma once
#include "Vector3.h"
#include "Rigidbody.h"
#include <vector>

class RigidForceGenerator
{
public:
	virtual void updateRigidForce(Rigidbody *body, real duration) = 0;
};

class RigidForceRegistry
{
protected:
	
	struct ForceRegistration
	{
		Rigidbody *body;
		RigidForceGenerator *fg;
	};

	typedef std::vector<ForceRegistration> Registry;
	Registry registrations;

public:
	void add(Rigidbody* body, RigidForceGenerator *fg);
	void updateForces(real duration);
};

class TestForceAlpha : public RigidForceGenerator
{
public:
	virtual void updateRigidForce(Rigidbody *body, real duration);
};