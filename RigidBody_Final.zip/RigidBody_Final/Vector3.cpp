#pragma once
#include "Vector3.h"

const Vector3 Vector3::GRAVITY = Vector3(0, -9.8, 0);
const Vector3 Vector3::HIGH_GRAVITY = Vector3(0, -19.62, 0);
const Vector3 Vector3::UP = Vector3(0, 1, 0);
const Vector3 Vector3::RIGHT = Vector3(1, 0, 0);
const Vector3 Vector3::OUT_OF_SCREEN = Vector3(0, 0, 1);
const Vector3 Vector3::X = Vector3(0, 1, 0);
const Vector3 Vector3::Y = Vector3(1, 0, 0);
const Vector3 Vector3::Z = Vector3(0, 0, 1);

/*
 * Definition of the sleep epsilon extern.
 */
real sleepEpsilon = ((real)0.3);

/*
 * Functions to change sleepEpsilon.
 */
void setSleepEpsilon(real value)
{
    sleepEpsilon = value;
}

real getSleepEpsilon()
{
    return sleepEpsilon;
}

//Flips all the components of the vector
void Vector3::invert()
{
	x = -x;
	y = -y;
	z = -z;
}

//return magnitude of this vector
real Vector3::magnitude() const
{
	return sqrt(x*x+y*y+z*z);
}

//return square of this vector
real Vector3::squareMagnitude() const
{
	return x*x+y*y+z*z;
}

//turns a non-zero vector into a unit vector
void Vector3::normalize()
{
	real l = magnitude();
	if(l > 0)
	{
		(*this) *= ((real)1)/l;
	}
}

//multiply this vector by a scalar
void Vector3::operator*=(const real value)
{
	x *= value;
	y *= value;
	z *= value;
}

//returns a copy of this vector scaled by value
Vector3 Vector3::operator*(const real value) const
{
	return Vector3(x*value, y*value, z*value);
}

//Adds the given vector to this
void Vector3::operator+=(const Vector3 &v)
{
	x += v.x;
	y += v.y;
	z += v.z;
}

//returns value of given vector added to this
Vector3 Vector3::operator+(const Vector3 &v) const
{
	return Vector3(x+v.x, y+v.y, z+v.z);
}

//subtracts the given vector to this
void Vector3::operator-=(const Vector3 &v)
{
	x -= v.x;
    y -= v.y;
    z -= v.z;
}

//returns value of given vector subtracted from this
Vector3 Vector3::operator-(const Vector3 &v) const
{
	return Vector3(x-v.x, y-v.y, z-v.z);
}

//Adds the given vector to this, scaled by given amount
void Vector3::addScaledVector(const Vector3 &vector, real scale)
{
	x += vector.x * scale;
    y += vector.y * scale;
    z += vector.z * scale;
}

//Calculates & returns component-wise product of this vector with given vector
Vector3 Vector3::componentProduct(const Vector3 &vector) const
{
	return Vector3(x * vector.x, y * vector.y, z * vector.z);
}

//Performs component-wise product with given vector and sets this vector to its result
void Vector3::componentProductUpdate(const Vector3 &vector)
{
	x *= vector.x;
    y *= vector.y;
    z *= vector.z;
}

//calculates & returns scalar product of this vector with given vector
real Vector3::operator*(const Vector3 &vector) const
{
	return x*vector.x + y*vector.y + z*vector.z;
}

//calculate & returns vector product of this vector with a given vector
//LONG-HAND version of following overloaded operators
Vector3 Vector3::vectorProduct(const Vector3 &vector) const
{
	return Vector3(y*vector.z - z*vector.y,
				   z*vector.x - x*vector.z,
				   x*vector.y - y*vector.x);
}

//updates this vector to be the vector product of it and a given vector
void Vector3::operator%=(const Vector3 &vector)
{
	*this = vectorProduct(vector); 
}

//calculate & returns vector product of this vector with a given vector
Vector3 Vector3::operator%(const Vector3 &vector) const
{
	return Vector3(y*vector.z - z*vector.y,
				   z*vector.x - x*vector.z,
				   x*vector.y - y*vector.x);
}

Vector3 Vector3::unit() const
{
	Vector3 result = *this;
	result.normalize();
	return result;
}

//comparison operator overrides for Vector3
bool Vector3::operator==(const Vector3 &other) const
{
	return x == other.x &&
		   y == other.y &&
		   z == other.z;
}

bool Vector3::operator!=(const Vector3 &other) const
{
	return !(*this == other);
}

bool Vector3::operator<(const Vector3 &other) const
{
	return x < other.x &&
		   y < other.y &&
		   z < other.z;
}

bool Vector3::operator>(const Vector3 &other) const
{
	return x > other.x &&
		   y > other.y &&
		   z > other.z;
}

bool Vector3::operator<=(const Vector3 &other) const
{
	return x <= other.x &&
		   y <= other.y &&
		   z <= other.z;
}

bool Vector3::operator>=(const Vector3 &other) const
{
	return x >= other.x &&
		   y >= other.y &&
		   z >= other.z;
}

//reset all values
void Vector3::clear()
{
    x = y = z = 0;
}

real Vector3::scalarProduct(const Vector3 &vector) const
{
	return x*vector.x + y*vector.y + z*vector.z;
}
