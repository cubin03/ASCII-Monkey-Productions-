#pragma once
#include <cstdlib>
#include "RigidWorld.h"

RigidWorld::RigidWorld(unsigned maxContacts, unsigned iterations)
:firstBody(NULL)
,firstContactGen(NULL)
,resolver(iterations)
,maxContacts(maxContacts)
{
	contacts = new Contact[maxContacts];
	calculateIterations = (iterations == 0);
}

RigidWorld::~RigidWorld()
{
	delete[] contacts;
}

void RigidWorld::startFrame()
{
	BodyRegistration *reg = firstBody;

	while(reg)
	{
		reg->body->clearAccumulators();
		reg->body->calculateDerivedData();
		
		reg = reg->next;
	}
}

unsigned RigidWorld::generateContacts()
{
	unsigned limit = maxContacts;
	Contact *nextContact = contacts;

	ContactGenRegistration *reg = firstContactGen;

	while(reg)
	{
		unsigned used = reg->gen->addContact(nextContact, limit);
		limit -= used;
		nextContact += used;

		if(limit <= 0) break;

		reg = reg->next;
	}

	return maxContacts - limit;
}

void RigidWorld::runPhysics(real duration)
{
	BodyRegistration *reg = firstBody;

	while(reg)
	{
		reg->body->integrate(duration);

		reg = reg->next;
	}

	unsigned usedContacts = generateContacts();

	if(calculateIterations)
	{
		resolver.setIterations(usedContacts * 4);
	}

	resolver.resolveContacts(contacts, usedContacts, duration);
}