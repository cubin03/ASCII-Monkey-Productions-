#pragma once
#include "RigidForceGen.h"

void RigidForceRegistry::updateForces(real duration)
{
    Registry::iterator i = registrations.begin();
    for (; i != registrations.end(); i++)
    {
        i->fg->updateRigidForce(i->body, duration);
    }
}

void RigidForceRegistry::add(Rigidbody *body, RigidForceGenerator *fg)
{
    RigidForceRegistry::ForceRegistration registration;
    registration.body = body;
    registration.fg = fg;
    registrations.push_back(registration);
}