#pragma once
#include "Particle.h"


Particle::Particle()
:position(Vector3(0,0,0))
,velocity(Vector3(0,0,0))
,acceleration(Vector3(0,0,0))
,forceAccum(Vector3(0,0,0))
,damping(0.0)
,inverseMass(0.0)
{
}

//integrates the particle forward in time by given amount
//this uses Newton-Euler integration method
void Particle::integrate(real duration)
{
	//don't integrate things with infinite mass
	if(inverseMass <= 0.0f) return;

	assert(duration > 0.0);

	//update position
	position.addScaledVector(velocity, duration);

	//determine acceleration from the force
	Vector3 resultingAcc = acceleration;
	resultingAcc.addScaledVector(forceAccum, inverseMass);

	//update velocity from acceleration
	velocity.addScaledVector(resultingAcc, duration);

	//impose drag
	velocity *= real_pow(damping, duration);

	//clear forces
	clearAccumulator();
}

/////////////////////////////////////////////////////////
//Accessor functions
////////////////////////////////////////////////////////
void Particle::setMass(const real mass)
{
	assert(mass != 0);
	Particle::inverseMass = ((real)1.0)/mass;
}

real Particle::getMass() const
{
	if(inverseMass == 0)
	{
		return REAL_MAX;
	}
	else
	{
		return ((real)1.0)/inverseMass;
	}
}

void Particle::setInverseMass(const real iMass)
{
	inverseMass = iMass;
}

real Particle::getInverseMass() const
{
	return inverseMass;
}

bool Particle::hasFiniteMass() const
{
	return inverseMass >= 0.0f;
}

void Particle::setDamping(const real damp)
{
	damping = damp;
}

real Particle::getDamping() const
{
    return damping;
}

void Particle::setPosition(const Vector3 &pos)
{
    position = pos;
}

void Particle::setPosition(const real x, const real y, const real z)
{
    position.x = x;
    position.y = y;
    position.z = z;
}

void Particle::getPosition(Vector3 *pos) const
{
    *pos = position;
}

Vector3 Particle::getPosition() const
{
    return position;
}

void Particle::setVelocity(const Vector3 &vel)
{
    velocity = vel;
}

void Particle::setVelocity(const real x, const real y, const real z)
{
    velocity.x = x;
    velocity.y = y;
    velocity.z = z;
}

void Particle::getVelocity(Vector3 *vel) const
{
    *vel = velocity;
}

Vector3 Particle::getVelocity() const
{
    return velocity;
}

void Particle::setAcceleration(const Vector3 &acc)
{
    acceleration = acc;
}

void Particle::setAcceleration(const real x, const real y, const real z)
{
    acceleration.x = x;
    acceleration.y = y;
    acceleration.z = z;
}

void Particle::getAcceleration(Vector3 *acc) const
{
    *acc = acceleration;
}

Vector3 Particle::getAcceleration() const
{
    return acceleration;
}

void Particle::setRadius(const real rad)
{
	radius = rad;
}

real Particle::getRadius() const
{
	return radius;
}

//////////////////////////////////////////////////////////////////////

//clears the forces applied to the particle
void Particle::clearAccumulator()
{
    forceAccum.clear();
}

//Adds the given force to the particle
void Particle::addForce(const Vector3 &force)
{
    forceAccum += force;
}