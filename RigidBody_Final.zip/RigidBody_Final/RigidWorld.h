#pragma once
#include <cstdlib>
#include "Rigidbody.h"
#include "RigidCollision.h"
#include <vector>

class RigidWorld
{
	bool calculateIterations;

	struct BodyRegistration
	{
		Rigidbody* body;
		BodyRegistration* next;
	};

	struct ContactGenRegistration
	{
		ContactGenerator *gen;
		ContactGenRegistration *next;
	};

	BodyRegistration* firstBody;
	RigidContactResolver resolver;
	ContactGenRegistration *firstContactGen;
	Contact *contacts;
	unsigned maxContacts;

public:
	RigidWorld(unsigned maxCounts, unsigned iterations=0);
	~RigidWorld();

	unsigned generateContacts();
	void runPhysics(real duration);
	void startFrame();
};