/*Author: Ian Cubin
**Date:   01/13/13
**External Resources: Ian Millington
*
*
**Description: This is the start of my physics engine
*/
#pragma once
#include <iostream>
#include <stdlib.h>
#include <math.h>
#include <vector>
#include <stdio.h>

#ifdef __APPLE__
#include <OpenGL/OpenGL.h>
#include <GLUT/glut.h>
#else
#include <GL/glut.h>	
#endif

#include "imageloader.h" //Provided thanks to OpenGL tutorial
#include "Camera.h"
#include "Rigidbody.h"
#include "timing.h"
#include "RigidForceGen.h"
#include "RigidCollision.h"
#include "RigidWorld.h"
#include "Primitives.h"
#include "Random.h"

#define MAX_BLOCKS 9

using namespace std;

class Block : public CollisionBox
{
public:
	bool exists;

	Block()
	:exists(false)
	{
		body = new Rigidbody();
	}

	~Block()
	{
		delete body;
	}

	void render()
	{
		GLfloat mat[16];
		body->getGLTransform(mat);

		glColor3f(1.0f, 0.7f, 0.7f);
		glPushMatrix();
		glMultMatrixf(mat);
		glScalef(halfSize.x*2, halfSize.y*2, halfSize.z*2);
		glutSolidCube(1.0f);
		glPopMatrix();
	}

	void setState(const Vector3 &position, const Quaternion &orientation, const Vector3 &extents, const Vector3 &velocity)
	{
		body->setPosition(position);
		body->setOrientation(orientation);
		body->setVelocity(velocity);
		body->setRotation(Vector3(0,0,0));
		halfSize = extents;

		real mass = halfSize.x * halfSize.y * halfSize.z * 0.8f;
		body->setMass(mass);

		Matrix3 tensor;
		tensor.setBlockInertiaTensor(halfSize, mass);
		body->setInertiaTensor(tensor);

		body->setLinearDamping(0.95f);
		body->setAngularDamping(0.8f);
		body->clearAccumulators();
		body->setAcceleration(0, -10.0f, 0);

		body->setAwake();

		body->calculateDerivedData();
	}

	void calculateMassProperties(real invDensity)
	{
		if(invDensity <= 0)
		{
			body->setInverseMass(0);
			body->setInverseInertiaTensor(Matrix3());
		}
		else
		{
			real volume = halfSize.magnitude() * 2.0;
			real mass = volume / invDensity;

			body->setMass(mass);

			mass *= 0.333f;
			Matrix3 tensor;
			tensor.setInertiaTensorCoeffs(
				mass * halfSize.y*halfSize.y + halfSize.z*halfSize.z,
				mass * halfSize.y*halfSize.x + halfSize.z*halfSize.z,
				mass * halfSize.y*halfSize.x + halfSize.z*halfSize.y
			);
			body->setInertiaTensor(tensor);
		}
	}

	void divideBlock(const Contact& contact, Block* target, Block* blocks)
    {
        // Find what block we are and get the inverse normal
        Vector3 normal = contact.contactNormal;
        Rigidbody *body = contact.body[0];
        if (body != target->body)
        {
            normal.invert();
            body = contact.body[1];
        }

        // Figure out where on the body the point of contact is and direction
        Vector3 point = body->getPointInLocalSpace(contact.contactPoint);
        normal = body->getDirectionInLocalSpace(normal);

        // Find the split: this is the point coordinates
        // for each of the axes perpendicular to the normal, and 0 for the
        // axis along the normal.
        point = point - normal * (point * normal);

        // Take a copy of the half size, so we can create the new blocks.
        Vector3 size = target->halfSize;

        // Take a copy also of the body's other data.
        Rigidbody tempBody;
        tempBody.setPosition(body->getPosition());
        tempBody.setOrientation(body->getOrientation());
        tempBody.setVelocity(body->getVelocity());
        tempBody.setRotation(body->getRotation());
        tempBody.setLinearDamping(body->getLinearDamping());
        tempBody.setAngularDamping(body->getAngularDamping());
        tempBody.setInverseInertiaTensor(body->getInverseInertiaTensor());
        tempBody.calculateDerivedData();

        // Remove the old block
        target->exists = false;

        // Figure out the inverse density of the old block
        real invDensity = halfSize.magnitude()*8 * body->getInverseMass();

        // Split the block.
        for (unsigned i = 0; i < MAX_BLOCKS-1; i++)
        {
            // Find the minimum and maximum extents of the new blocks
            // in old-block coordinates
            Vector3 min, max;
            if ((i & 1) == 0) {
                min.x = -size.x;
                max.x = point.x;
            } else {
                min.x = point.x;
                max.x = size.x;
            }
            if ((i & 2) == 0) {
                min.y = -size.y;
                max.y = point.y;
            } else {
                min.y = point.y;
                max.y = size.y;
            }
            if ((i & 4) == 0) {
                min.z = -size.z;
                max.z = point.z;
            } else {
                min.z = point.z;
                max.z = size.z;
            }

            // Get the origin and half size of the block, in old-body
            // local coordinates.
            Vector3 halfSize = (max - min) * 0.5f;
            Vector3 newPos = halfSize + min;

            // Convert the origin to world coordinates.
            newPos = tempBody.getPointInWorldSpace(newPos);

            // Figure out the direction to the impact.
            Vector3 direction = newPos - contact.contactPoint;
            direction.normalize();

            // Set the body's properties
            blocks[i].body->setPosition(newPos);
            blocks[i].body->setVelocity(tempBody.getVelocity() + direction * 10.0f);
            blocks[i].body->setOrientation(tempBody.getOrientation());
            blocks[i].body->setRotation(tempBody.getRotation());
            blocks[i].body->setLinearDamping(tempBody.getLinearDamping());
            blocks[i].body->setAngularDamping(tempBody.getAngularDamping());
            blocks[i].body->setAwake(true);
            blocks[i].body->setAcceleration(Vector3::GRAVITY);
            blocks[i].body->clearAccumulators();
            blocks[i].body->calculateDerivedData();
            blocks[i].offset = Matrix4();
            blocks[i].exists = true;
            blocks[i].halfSize = halfSize;

            // Calculate the mass and inertia tensor of the new block
            blocks[i].calculateMassProperties(invDensity);
        }
	}
};

const float BOX_SIZE = 6.0f;
const float CAMERASPEED = 0.2f;

const static unsigned maxContacts = 256;

CCamera objCamera;

GLuint _textureId2;           //The id of the background texture
//bool fired;

Contact contacts[maxContacts];
CollisionData cData;
RigidContactResolver resolver(maxContacts*8);

bool hit;
bool destroyed;
bool ball_active;
unsigned fracture_contact;
Random random;
Block blocks[MAX_BLOCKS];
CollisionSphere ball;

//Forward declarations
//////////////////////
void loadRoom();
void fireProjectile();
void init();
void reset();
void updateObjects(real duration);
void generateContacts();
//////////////////////

//Makes the image into a texture, and returns the id of the texture
//Provided thanks to OpenGL tutorial
GLuint loadTexture(Image* image) 
{
	GLuint textureId;
	glGenTextures(1, &textureId);
	glBindTexture(GL_TEXTURE_2D, textureId);
	glTexImage2D(GL_TEXTURE_2D,
				 0,
				 GL_RGB,
				 image->width, image->height,
				 0,
				 GL_RGB,
				 GL_UNSIGNED_BYTE,
				 image->pixels);
	return textureId;
}

//Setup render calls and load images
void initRendering() 
{
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0);
	glEnable(GL_NORMALIZE);
	glEnable(GL_COLOR_MATERIAL);
	glClearColor(0.5f, 0.5f, 0.5f, 1);

	objCamera.Position_Camera(0.0f, 5.0f, -20.0f,	0, 5.0f, 0,   0, 1, 0);

	Image* image1 = loadBMP("metalplate.bmp");
	_textureId2 = loadTexture(image1);
	delete image1;
}

//Handles the viewport and projection matrix of the window
void handleResize(int w, int h) 
{
	if (h==0)//Prevent A Divide By Zero By...
	{
		h=1; //Making Height Equal One
	}
	glViewport(0, 0, w, h);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(45.0, (float)w / (float)h, 1.0, 350.0);
}

//Render the scene
void drawScene() 
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	//Create an ambient light
	GLfloat ambientLight[] = {0.8f, 0.8f, 0.8f, 1.0f};
	glLightModelfv(GL_LIGHT_MODEL_AMBIENT, ambientLight);
	
	GLfloat lightColor[] = {0.8f, 0.8f, 0.8f, 1.0f};
	GLfloat lightPos[] = {-2 * BOX_SIZE, BOX_SIZE, 4 * BOX_SIZE, 1.0f}; //Position light 
	glLightfv(GL_LIGHT0, GL_DIFFUSE, lightColor);
	glLightfv(GL_LIGHT0, GL_POSITION, lightPos);

	//Enable and declare texture properties
	glEnable(GL_TEXTURE_2D);
	glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
	glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
	glTexGeni(GL_R, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glColor3f(1.0f, 1.0f, 1.0f);

	////////////////////////////////////////////////////////////////////////////////////////////////

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	gluLookAt(objCamera.mPos.x,  objCamera.mPos.y,  objCamera.mPos.z,	
			  objCamera.mView.x, objCamera.mView.y, objCamera.mView.z,	
			  objCamera.mUp.x,   objCamera.mUp.y,   objCamera.mUp.z);

	glEnable(GL_NORMALIZE);
	for(Block* block = blocks; block < blocks+MAX_BLOCKS; block++)
	{
		if(block->exists)
			block->render();
	}
	glDisable(GL_NORMALIZE);

	if(ball_active)
	{
		glColor3f(0.4f, 0.7f, 0.4f);
		glPushMatrix();
		Vector3 pos = ball.body->getPosition();
		glTranslatef(pos.x, pos.y, pos.z);
		glutSolidSphere(0.25f, 16, 8);
		glPopMatrix();
	}

	glBindTexture(GL_TEXTURE_2D, _textureId2);

    //Draw room
	glColor3f(1.0f, 1.0f, 1.0f);
	glPushMatrix();
	glTranslatef(0.0, BOX_SIZE, 0.0f);
    glBegin(GL_QUADS);
	loadRoom();
    glEnd();
	glPopMatrix();
	
	glutSwapBuffers();
}

void Keyboard_Input(unsigned char key, int x, int y)
{
	if((GetKeyState(VK_UP) & 0x80) || (GetKeyState('W') & 0x80))
	{	
		objCamera.Move_Camera( CAMERASPEED);
	}

	if((GetKeyState(VK_DOWN) & 0x80) || (GetKeyState('S') & 0x80))
	{
		objCamera.Move_Camera(-CAMERASPEED);
	}

	if((GetKeyState(VK_LEFT) & 0x80) || (GetKeyState('A') & 0x80))
	{	
		objCamera.Strafe_Camera(-1.0f);
	}

	if((GetKeyState(VK_RIGHT) & 0x80) || (GetKeyState('D') & 0x80))
	{
		objCamera.Strafe_Camera(1.0f);
	}

	if((GetKeyState(VK_ESCAPE) & 0x80))
	{
		exit(0);
	}

	if(GetKeyState('R') & 0x80)
	{
		reset();
	}
}

void fireProjectile()
{
	Vector3 cameraNormals = objCamera.mView - objCamera.mPos;

	ball_active = true;

	ball.body->setPosition(objCamera.mPos.x, objCamera.mPos.y, objCamera.mPos.z);
	ball.body->setOrientation(1,0,0,0);
    ball.body->setVelocity(2.0f * cameraNormals.x, 2.0f * cameraNormals.y, 2.0f * cameraNormals.z);
    ball.body->setRotation(0,0,0);
    ball.body->calculateDerivedData();
    ball.body->setAwake(true);
    ball.calculateInternals();
}

void mouse(int button, int state, int x, int y)
{
	if(state == GLUT_DOWN)
	{
		fireProjectile();
	}
}

//Called every time step
void update() 
{
	TimingData::get().update();

	float duration = (float)TimingData::get().lastFrameDuration * 0.001f;
	if (duration <= 0.0f) 
		return;

	updateObjects(duration);

	generateContacts();

	resolver.resolveContacts(cData.contactArray, cData.contactCount, duration);

	if(hit)
	{
		blocks[0].divideBlock(cData.contactArray[fracture_contact], blocks, blocks+1);
		ball_active = false;
	}

	objCamera.Mouse_Move(0,0, 640, 480);

	glutPostRedisplay();
}

void updateObjects(real duration)
{
	for (Block *block = blocks; block < blocks+MAX_BLOCKS; block++)
    {
        if (block->exists)
        {
            block->body->integrate(duration);
            block->calculateInternals();
        }
    }

    if (ball_active)
    {
        ball.body->integrate(duration);
        ball.calculateInternals();
    }
}

void reset()
{
	blocks[0].exists = true;

	for(Block* block = blocks+1; block < blocks+MAX_BLOCKS; block++)
	{
		block->exists = false;
	}

	blocks[0].halfSize = Vector3(4, 4, 4);
	blocks[0].body->setPosition(0, 20, 0);
	blocks[0].body->setOrientation(1, 0, 0, 0);
	blocks[0].body->setVelocity(0, 0, 0);
	blocks[0].body->setRotation(0, 0, 0);
	blocks[0].body->setMass(100.0f);

	Matrix3 it;
	it.setBlockInertiaTensor(blocks[0].halfSize, 100.0f);
	blocks[0].body->setInertiaTensor(it);

	blocks[0].body->setDamping(0.9f, 0.9f);
	blocks[0].body->calculateDerivedData();
	blocks[0].calculateInternals();

	blocks[0].body->setAcceleration(Vector3::GRAVITY);
	blocks[0].body->setAwake(true);
	blocks[0].body->setCanSleep(true);

	ball_active = false;
    hit = false;
	destroyed = false;

    // Reset the contacts
    cData.contactCount = 0;
}

void init()
{
	ball.body = new Rigidbody();
	ball.radius = 0.25f;
	ball.body->setMass(5.0f);
	ball.body->setDamping(0.9f, 0.9f);

	Matrix3 it;
	it.setDiagonal(5.0f, 5.0f, 5.0f);
	ball.body->setInertiaTensor(it);
	ball.body->setAcceleration(Vector3::GRAVITY);

	ball.body->setCanSleep(false);
	ball.body->setAwake(true);

	reset();
}

void generateContacts()
{
	hit = false;

    // Create the ground plane data
    CollisionPlane plane;
    plane.direction = Vector3(0,1,0);
    plane.offset = 0;

    // Set up the collision data structure
    cData.reset(maxContacts);
    cData.friction = (real)0.9;
    cData.restitution = (real)0.2;
    cData.tolerance = (real)0.1;

    // Perform collision detection
    Matrix4 transform, otherTransform;
    Vector3 position, otherPosition;
    for (Block *block = blocks; block < blocks+MAX_BLOCKS; block++)
    {
        if (!block->exists) continue;

        // Check for collisions with the ground plane
        if (!cData.hasMoreContacts()) return;
        CollisionDetector::boxAndHalfSpace(*block, plane, &cData);

        if (ball_active)
        {
            // And with the sphere
            if (!cData.hasMoreContacts()) return;
            if (CollisionDetector::boxAndSphere(*block, ball, &cData) && !destroyed)
            {
                hit = true;
				destroyed = true;
                fracture_contact = cData.contactCount-1;
            }
        }

        // Check for collisions with each other box
        for (Block *other = block+1; other < blocks+MAX_BLOCKS; other++)
        {
            if (!other->exists) continue;

            if (!cData.hasMoreContacts()) return;
            CollisionDetector::boxAndBox(*block, *other, &cData);
        }
    }

    // Check for sphere ground collisions
    if (ball_active)
    {
        if (!cData.hasMoreContacts()) return;
        CollisionDetector::sphereAndHalfSpace(ball, plane, &cData);
    }
}

int main(int argc, char** argv) 
{
	glutInit(&argc, argv);
	TimingData::init();
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
	glutInitWindowSize(1280, 720);
	
	glutCreateWindow("Fracture Physics");

	cData.contactArray = contacts;

	init();

	initRendering();
	
	glutDisplayFunc(drawScene);
	glutKeyboardFunc(Keyboard_Input);
	glutReshapeFunc(handleResize);
	glutMouseFunc(mouse);
	glutIdleFunc(update);
	
	glutMainLoop();

	TimingData::deinit();

	return 0;
}

//Creates the background vertices and texture coordinates
void loadRoom()
{
	//Top Face
	glNormal3f(0.0, 1.0f, 0.0f);
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(-BOX_SIZE*(20), BOX_SIZE*(20), -BOX_SIZE*(20));
	glTexCoord2f(1.0f, 0.0f);
	glVertex3f(-BOX_SIZE*(20), BOX_SIZE*(20), BOX_SIZE*(20));
	glTexCoord2f(1.0f, 1.0f);
	glVertex3f(BOX_SIZE*(20), BOX_SIZE*(20), BOX_SIZE*(20));
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(BOX_SIZE*(20), BOX_SIZE*(20), -BOX_SIZE*(20));

	//Bottom Face
	glNormal3f(0.0, -1.0f, 0.0f);
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(-BOX_SIZE*(20), -BOX_SIZE*(1), -BOX_SIZE*(20));
	glTexCoord2f(1.0f, 0.0f);
	glVertex3f(BOX_SIZE*(20), -BOX_SIZE*(1), -BOX_SIZE*(20));
	glTexCoord2f(1.0f, 1.0f);
	glVertex3f(BOX_SIZE*(20), -BOX_SIZE*(1), BOX_SIZE*(20));
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(-BOX_SIZE*(20), -BOX_SIZE*(1), BOX_SIZE*(20));

	//Back Face
	glNormal3f(0.0, 1.0f, 0.0f);
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(-BOX_SIZE*(20), -BOX_SIZE*(20), -BOX_SIZE*(20));
	glTexCoord2f(1.0f, 0.0f);
	glVertex3f(-BOX_SIZE*(20), BOX_SIZE*(20), -BOX_SIZE*(20));
	glTexCoord2f(1.0f, 1.0f);
	glVertex3f(BOX_SIZE*(20), BOX_SIZE*(20), -BOX_SIZE*(20));
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(BOX_SIZE*(20), -BOX_SIZE*(20), -BOX_SIZE*(20));

	//Front face
	glNormal3f(0.0, 0.0f, 1.0f);
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(-BOX_SIZE*(20), -BOX_SIZE*(20), BOX_SIZE*(20));
	glTexCoord2f(1.0f, 0.0f);
	glVertex3f(BOX_SIZE*(20), -BOX_SIZE*(20), BOX_SIZE*(20));
	glTexCoord2f(1.0f, 1.0f);
	glVertex3f(BOX_SIZE*(20), BOX_SIZE*(20), BOX_SIZE*(20));
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(-BOX_SIZE*(20), BOX_SIZE*(20), BOX_SIZE*(20));

	//Left face
	glNormal3f(-1.0, 0.0f, 0.0f);
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(-BOX_SIZE*(20), -BOX_SIZE*(20), -BOX_SIZE*(20));
	glTexCoord2f(1.0f, 0.0f);
	glVertex3f(-BOX_SIZE*(20), -BOX_SIZE*(20), BOX_SIZE*(20));
	glTexCoord2f(1.0f, 1.0f);
	glVertex3f(-BOX_SIZE*(20), BOX_SIZE*(20), BOX_SIZE*(20));
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(-BOX_SIZE*(20), BOX_SIZE*(20), -BOX_SIZE*(20));

	//Right Face
	glNormal3f(1.0, 0.0f, 0.0f);
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(BOX_SIZE*(20), -BOX_SIZE*(20), -BOX_SIZE*(20));
	glTexCoord2f(1.0f, 0.0f);
	glVertex3f(BOX_SIZE*(20), BOX_SIZE*(20), -BOX_SIZE*(20));
	glTexCoord2f(1.0f, 1.0f);
	glVertex3f(BOX_SIZE*(20), BOX_SIZE*(20), BOX_SIZE*(20));
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(BOX_SIZE*(20), -BOX_SIZE*(20), BOX_SIZE*(20));
}









