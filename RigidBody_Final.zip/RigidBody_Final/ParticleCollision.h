#pragma once
#include <iostream>
#include "Vector3.h"
#include "Particle.h"
#include <vector>

class ContactResolver;

class ParticleContact
{
	friend ContactResolver;

public:
	Particle* particle[2]; //holds particles involved in the contact

	//holds data related to the contact point
	real restitution;
	Vector3 contactNormal;
	real penetration;

	//holds amount each particle gets moved by interpenetration resolution
	Vector3 particleMovement[2];

	void resolve(real duration); //resolve the contact

protected:
	real calcSeparationVelocity() const; //calculates velocity needed to seperate this contact

private:
	void resolveVelocity(real duration); //handles impulse calculations
	void resolveInterpenetration(real duration); //handles the interpenetration resolution

};

class ContactResolver
{
protected:
	unsigned iterations;
	unsigned iterationsUsed;

public:
	ContactResolver(unsigned iterations);

	void setIterations(unsigned iterations);

	void resolveContacts(ParticleContact *contactArray, unsigned numContacts, real duration);
};

class ContactGenerator
{
public:
	virtual unsigned addContact(ParticleContact *contact, unsigned limit) const = 0;
};

class ObjectContacts : public ContactGenerator
{
public:
	Particle* particle[2];

	virtual unsigned addContact(ParticleContact * contact, unsigned limit) const;
};

class ParticleLink : public ContactGenerator
{
public:
	Particle* particle[2];

//protected:
	//real currentLength() const;

//public:
	virtual unsigned addContact(ParticleContact *contact, unsigned limit) const = 0;
};

class ParticleCable : public ParticleLink
{
public:
	real maxLength;
	real restitution;

public:
	virtual unsigned addContact(ParticleContact *contact, unsigned limit) const;
};

class ParticleRod : public ParticleLink
{
public:
	real length;

	virtual unsigned addContact(ParticleContact* contact, unsigned limit) const;
};