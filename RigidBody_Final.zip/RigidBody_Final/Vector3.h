#pragma once
#include <math.h>
#include "Precision.h"

extern real sleepEpsilon;
void setSleepEpsilon(real value);
real getSleepEpsilon();

class Vector3
{
public:
	real x;
	real y;
	real z;

	Vector3(): x(0), y(0), z(0) {} //default contruct

	//explicit construct
	Vector3(const real x, const real y, const real z)
		:x(x), y(y), z(z) {}

	const static Vector3 GRAVITY;
    const static Vector3 HIGH_GRAVITY;
    const static Vector3 UP;
    const static Vector3 RIGHT;
    const static Vector3 OUT_OF_SCREEN;
    const static Vector3 X;
    const static Vector3 Y;
    const static Vector3 Z;

	//Flips all the components of the vector
	void invert();

	//return magnitude of this vector
	real magnitude() const;

	//return square of this vector
	real squareMagnitude() const;

	//turns a non-zero vector into a unit vector
	void normalize();

	//multiply this vector by a scalar
	void operator*=(const real value);

	//returns a copy of this vector scaled by value
	Vector3 operator*(const real value) const;

	//Adds the given vector to this
	void operator+=(const Vector3& v);

	//returns value of given vector added to this
	Vector3 operator+(const Vector3& v) const;

	//subtracts the given vector to this
	void operator-=(const Vector3& v);

	//returns value of given vector subtracted from this
    Vector3 operator-(const Vector3& v) const;

	//Adds the given vector to this, scaled by given amount
	void addScaledVector(const Vector3& vector, real scale);

	//Calculates & returns component-wise product of this vector with given vector
	Vector3 componentProduct(const Vector3 &vector) const;

	//Performs component-wise product with given vector and sets this vector to its result
    void componentProductUpdate(const Vector3 &vector);

	//calculates & returns scalar product of this vector with given vector
	real operator*(const Vector3 &vector) const;

	//calculate & returns vector product of this vector with a given vector
	//LONG-HAND version of following overloaded operators
	Vector3 vectorProduct(const Vector3 &vector) const;

	//updates this vector to be the vector product of it and a given vector
	void operator%=(const Vector3 &vector);

	//calculate & returns vector product of this vector with a given vector
	Vector3 operator%(const Vector3 &vector) const;

	Vector3 unit() const;

	//Comparison operator overrides for Vector3
	bool operator==(const Vector3 &other) const;

	bool operator!=(const Vector3 &other) const;

	bool operator<(const Vector3 &other) const;

	bool operator>(const Vector3 &other) const;

	bool operator<=(const Vector3 &other) const;

	bool operator>=(const Vector3 &other) const;

	real operator[](unsigned i) const
	{
		if(i == 0) return x;
		if(i == 1) return y;
		return z;
	}

	real& operator[](unsigned i)
	{
		if(i == 0) return x;
		if(i == 1) return y;
		return z;
	}

	//reset values
	void clear();

	//Calculates and returns the scalar product of this vector with given vector
	real scalarProduct(const Vector3 &vector) const;

private:
	real pad; //purely for performance
};