#pragma once
#include <cstdlib>
#include "ForceGenerator.h"
#include "ParticleCollision.h"
#include <vector>

class ParticleWorld
{
public:
	typedef std::vector<Particle*> Particles;
	typedef std::vector<ContactGenerator*> ContactGenerators;

protected:
	Particles particles;
	bool calculateIterations;
	ForceRegistry registry;
	ContactResolver resolver;
	ContactGenerators contactGenerators;
	ParticleContact *contacts;
	unsigned maxContacts;

public:
	ParticleWorld(unsigned maxContacts, unsigned iterations=0);
	~ParticleWorld();

	unsigned generateContacts();
	void integrate(real duration);
	void runPhysics(real duration);
	void startFrame();

	Particles& getParticles();
	ContactGenerators& getContactGenerators();
	ForceRegistry& getForceRegistry();
};

class GroundContacts : public ContactGenerator
{
	ParticleWorld::Particles *particles;

public:
	void init(ParticleWorld::Particles *particles);

	virtual unsigned addContact(ParticleContact *contact, unsigned limit) const;
};