#pragma once
#include "ParticleCollision.h"

void ParticleContact::resolve(real duration)
{
	resolveVelocity(duration);
	resolveInterpenetration(duration);
}

real ParticleContact::calcSeparationVelocity() const
{
	Vector3 relativeVelocity = particle[0]->getVelocity();

	if(particle[1] != NULL)
	{
		relativeVelocity -= particle[1]->getVelocity();
	}

	return relativeVelocity * contactNormal;
}

void ParticleContact::resolveVelocity(real duration)
{
	real separatingVelocity = calcSeparationVelocity();

	if(separatingVelocity > 0)
	{
		//contact is either separating or stationary
		//no impulse required regardless
		return;
	}

	real newSeparationVelocity = -separatingVelocity * restitution;

	Vector3 accCausedVelocity = particle[0]->getAcceleration();

	if(particle[1] != NULL)
	{
		accCausedVelocity -= particle[1]->getAcceleration();
	}

	real accCausedSepVelocity = accCausedVelocity * contactNormal * duration;

	if(accCausedSepVelocity < 0)
	{
		newSeparationVelocity += restitution * accCausedSepVelocity;

		//make sure we remove no more than was there
		if(newSeparationVelocity < 0)
		{
			newSeparationVelocity = 0;
		}
	}

	real deltaVelocity = newSeparationVelocity - separatingVelocity;

	//apply change in velocity to each object
	//based on their inverse mass
	real totalInverseMass = particle[0]->getInverseMass();

	if(particle[1] != NULL)
	{
		totalInverseMass += particle[1]->getInverseMass();
	}

	//impulses dont work with infinite mass
	if(totalInverseMass <= 0)
		return;

	//calc the impulse to apply
	real impulse = deltaVelocity / totalInverseMass;

	Vector3 impulsePerMass = contactNormal * impulse;

	//finally apply the impulse
	particle[0]->setVelocity(particle[0]->getVelocity() +
							 impulsePerMass * 
							 particle[0]->getInverseMass());

	if(particle[1] != NULL)
	{
		//particle 1 is always opposite direction
		particle[1]->setVelocity(particle[1]->getVelocity() +
								 impulsePerMass * 
								 -particle[1]->getInverseMass());
	}
}

void ParticleContact::resolveInterpenetration(real duration)
{
	//check if any penetration, otherwise skip this step
	if(penetration <= 0)
		return;

	//determine both objects inverse mass total
	real totalInverseMass = particle[0]->getInverseMass();

	if(particle[1] != NULL)
	{
		totalInverseMass += particle[1]->getInverseMass();
	}

	//we dont like infinite masses
	if(totalInverseMass <= 0)
		return;

	//find the amount of penetration resolution per unit
	Vector3 movePerMass = contactNormal * (penetration / totalInverseMass);

	//calculate the movement amounts
	particleMovement[0] = movePerMass * particle[0]->getInverseMass();

	if(particle[1] != NULL)
	{
		particleMovement[1] = movePerMass * -particle[1]->getInverseMass();
	}
	else
	{
		particleMovement[1].clear();
	}

	//apply the penetration resolution
	particle[0]->setPosition(particle[0]->getPosition() + particleMovement[0]);

	if(particle[1] != NULL)
	{
		particle[1]->setPosition(particle[1]->getPosition() + particleMovement[1]);
	}
}

ContactResolver::ContactResolver(unsigned iterations)
:iterations(iterations)
{
}

void ContactResolver::setIterations(unsigned iterations)
{
	ContactResolver::iterations = iterations;
}

void ContactResolver::resolveContacts(ParticleContact *contactArray, unsigned numContacts, real duration)
{
	unsigned i;

    iterationsUsed = 0;
    while(iterationsUsed < iterations)
    {
        // Find the contact with the largest closing velocity;
        real max = REAL_MAX;
        unsigned maxIndex = numContacts;
        for (i = 0; i < numContacts; i++)
        {
            real sepVel = contactArray[i].calcSeparationVelocity();
            if (sepVel < max &&
                (sepVel < 0 || contactArray[i].penetration > 0))
            {
                max = sepVel;
                maxIndex = i;
            }
        }

        // Do we have anything worth resolving?
        if (maxIndex == numContacts) break;

        // Resolve this contact
		//std::cout << "Resolving" << std::endl;
        contactArray[maxIndex].resolve(duration);

        // Update the interpenetrations for all particles
        Vector3 *move = contactArray[maxIndex].particleMovement;
        for (i = 0; i < numContacts; i++)
        {
            if (contactArray[i].particle[0] == contactArray[maxIndex].particle[0])
            {
                contactArray[i].penetration -= move[0] * contactArray[i].contactNormal;
            }
            else if (contactArray[i].particle[0] == contactArray[maxIndex].particle[1])
            {
                contactArray[i].penetration -= move[1] * contactArray[i].contactNormal;
            }
            if (contactArray[i].particle[1])
            {
                if (contactArray[i].particle[1] == contactArray[maxIndex].particle[0])
                {
                    contactArray[i].penetration += move[0] * contactArray[i].contactNormal;
                }
                else if (contactArray[i].particle[1] == contactArray[maxIndex].particle[1])
                {
                    contactArray[i].penetration += move[1] * contactArray[i].contactNormal;
                }
            }
        }

        iterationsUsed++;
	}
}

unsigned ObjectContacts::addContact(ParticleContact *contact, unsigned limit) const
{
	contact->particle[0] = particle[0];
	contact->particle[1] = particle[1];

	real totalRadius = (contact->particle[0]->getRadius() + contact->particle[1]->getRadius());
	totalRadius *= totalRadius;
	real particlesDistance = pow((contact->particle[0]->getPosition().x - contact->particle[1]->getPosition().x), 2) +
							pow((contact->particle[0]->getPosition().y - contact->particle[1]->getPosition().y), 2) +
							pow((contact->particle[0]->getPosition().z - contact->particle[1]->getPosition().z), 2);

	if(particlesDistance < totalRadius)
	{
		contact->contactNormal = (contact->particle[0]->getPosition() - contact->particle[1]->getPosition()).unit();
		contact->penetration = contact->particle[0]->getRadius()/2;
		contact->restitution = 0.3;
		return 1;
	}

	return 0;
}

unsigned ParticleCable::addContact(ParticleContact *contact,
                                    unsigned limit) const
{
    // Find the length of the cable
	Vector3 relativePos = contact->particle[0]->getPosition() - contact->particle[1]->getPosition();

    real length = relativePos.magnitude();

    // Check if we're over-extended
    if (length < maxLength)
    {
        return 0;
    }

    // Otherwise return the contact
    contact->particle[0] = particle[0];
    contact->particle[1] = particle[1];

    // Calculate the normal
    Vector3 normal = contact->particle[1]->getPosition() - contact->particle[0]->getPosition();
    normal.normalize();
    contact->contactNormal = normal;

    contact->penetration = length-maxLength;
    contact->restitution = restitution;

    return 1;
}

unsigned ParticleRod::addContact(ParticleContact *contact,
                                  unsigned limit) const
{
	contact->particle[0] = particle[0];
    contact->particle[1] = particle[1];

    // Find the length of the rod
    Vector3 relativePos = contact->particle[0]->getPosition() - contact->particle[1]->getPosition();

    real currentLen = relativePos.magnitude();

    // Check if we're over-extended
    if (currentLen == length)
    {
        return 0;
    }

    // Otherwise return the contact

    // Calculate the normal
    Vector3 normal = contact->particle[1]->getPosition() - contact->particle[0]->getPosition();
    normal.normalize();

    // The contact normal depends on whether we're extending or compressing
    if (currentLen > length) {
        contact->contactNormal = normal;
        contact->penetration = currentLen - length;
    } else {
        contact->contactNormal = normal * -1;
        contact->penetration = length - currentLen;
    }

    // Always use zero restitution (no bounciness)
    contact->restitution = 0;

    return 1;
}