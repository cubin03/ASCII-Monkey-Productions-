#pragma once
#include "Vector3.h"
#include <math.h>
#include <assert.h>
#include <GL/glut.h>

class Particle
{
protected:
	Vector3 position;
	Vector3 velocity;
	Vector3 acceleration;

	Vector3 forceAccum;

	//required to remove energy added through numerical instability
	real damping;

	//holds inverse mass of particle
	real inverseMass;

	real radius;

public:
	Particle();
	~Particle() {};

	//integrates the particle forward in time by given amount
	//this uses Newton-Euler integration method
	void integrate(real duration);

	//accessor methods
	void setMass(const real mass);
	real getMass() const;
	void setInverseMass(const real iMass);
	real getInverseMass() const;
	bool hasFiniteMass() const;
	void setDamping(const real dampen);
	real getDamping() const;
	void setPosition(const Vector3 &pos);							//set by vector
	void setPosition(const real x, const real y, const real z);			//set by component
	void getPosition(Vector3 *pos) const;							//fills given vector with position data
	Vector3 getPosition() const;
	void setVelocity(const Vector3 &vel);							//set by vector
	void setVelocity(const real x, const real y, const real z);			//set by component
	void getVelocity(Vector3 *vel) const;							//fills given vector with velocity data
	Vector3 getVelocity() const;
	void setAcceleration(const Vector3 &acc);						//set by vector
	void setAcceleration(const real x, const real y, const real z);	//set by component
	void getAcceleration(Vector3 *acc) const;								//fills given vector with velocity data
	Vector3 getAcceleration() const;
	void setRadius(const real rad);
	real getRadius() const;

	//clears the forces applied to the particle
	void clearAccumulator();

	//Adds the given force to the particle
	void addForce(const Vector3 &force);
};