#pragma once
#include "Vector3.h"
#include "Particle.h"
#include <vector>

/*
	Abstract class for force generations
*/
class ForceGenerator
{
public:

	//update forces on a given particle
	virtual void updateForce(Particle *particle, real duration) = 0;
};

/*
	Registery used to store forces for particles
*/
class ForceRegistry
{
protected:

	//keeps track of a particle and its force generator
	struct ForceRegistration
	{
		Particle *particle;
		ForceGenerator *forceGen;
	};

	//hold list of force registrations
	typedef std::vector<ForceRegistration> Registry;
	Registry registrations;

public:

	//Register the force with a particle
	void add(Particle* particle, ForceGenerator *fg);

	//removes a registration from the registry
	//void remove(Particle* particle, ForceGenerator *fg);

	//clear all registrations
	//void clear();

	//calls all the force generators to update forces
	void updateForces(real duration);
};

/*
	Basic gravitational force generator
*/
class ParticleGravity:public ForceGenerator
{
	Vector3 gravity;

public:
	ParticleGravity(const Vector3 &gravity);

	virtual void updateForce(Particle *particle, real duration);

};

/*
	Basic spring force generator
*/
class ParticleSpring:public ForceGenerator
{
	Particle *other;
	real springConstant;
	real restLength;

public:
	ParticleSpring(Particle *other, real springConstant, real restLength);

	virtual void updateForce(Particle *particle, real duration);
};

/*
	Spring force for an object attached to a fixed point
*/
class ParticleAnchoredSpring:public ForceGenerator
{
protected:
	Vector3 *anchor;
	real springConstant;
	real restLength;

public:
	ParticleAnchoredSpring();

	ParticleAnchoredSpring(Vector3 *anchor, real springConstant, real restLength);

	const Vector3* getAnchor() const { return anchor; }
	void setAnchor(Vector3 anchor) { anchor = anchor; }

	void init(Vector3 *anchor, real springConstant, real restLength);

	virtual void updateForce(Particle *particle, real duration);
};

/*
	Spring force adaptation for a homing missile
*/
class HomingMissile:public ForceGenerator
{
	Particle *other;
	real springConstant;
	real restLength;

public:
	HomingMissile(Particle *other, real springConstant, real restLength);

	virtual void updateForce(Particle *particle, real duration);
};