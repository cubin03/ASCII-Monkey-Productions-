#pragma once
#include "ForceGenerator.h"

//Start of Force Registry functions
void ForceRegistry::updateForces(real duration)
{
	Registry::iterator i = registrations.begin();
	for(; i != registrations.end(); i++)
	{
		i->forceGen->updateForce(i->particle, duration);
	}
}

void ForceRegistry::add(Particle* particle, ForceGenerator *fg)
{
	ForceRegistry::ForceRegistration registration;
	registration.particle = particle;
	registration.forceGen = fg;
	registrations.push_back(registration);
}
//End

//Start of gravitational functions
ParticleGravity::ParticleGravity(const Vector3& gravity)
:gravity(gravity)
{
}

void ParticleGravity::updateForce(Particle* particle, real duration)
{
	if(!particle->hasFiniteMass()) return;

	particle->addForce(gravity * particle->getMass());
}
//End

//Start of spring forces
ParticleSpring::ParticleSpring(Particle *other, real sc, real rl)
:other(other)
,springConstant(sc)
,restLength(rl)
{
}

void ParticleSpring::updateForce(Particle* particle, real duration)
{
	//Calculate the vector of the spring
	Vector3 force;
	particle->getPosition(&force);
	force -= other->getPosition();

	//Calculate the magnitude of the force
	real magnitude = force.magnitude();
	magnitude = real_abs(magnitude - restLength);
	magnitude *= springConstant;

	//Calculate the final force and apply it
	force.normalize();
	force *= -magnitude;
	particle->addForce(force);
}

ParticleAnchoredSpring::ParticleAnchoredSpring()
{
}

ParticleAnchoredSpring::ParticleAnchoredSpring(Vector3 *anchor, real sc, real rl)
:anchor(anchor)
,springConstant(sc)
,restLength(rl)
{
}

void ParticleAnchoredSpring::init(Vector3 *anchor, real springConstant, real restLength)
{
	ParticleAnchoredSpring::anchor = anchor;
	ParticleAnchoredSpring::springConstant = springConstant;
	ParticleAnchoredSpring::restLength = restLength;
}

void ParticleAnchoredSpring::updateForce(Particle* particle, real duration)
{
	Vector3 force;
	particle->getPosition(&force);
	force -= *anchor;

	real magnitude = force.magnitude();
	magnitude = (restLength - magnitude) * springConstant;

	force.normalize();
	force *= magnitude;
	particle->addForce(force);
}

HomingMissile::HomingMissile(Particle *other, real sc, real rl)
:other(other)
,springConstant(sc)
,restLength(rl)
{
}

void HomingMissile::updateForce(Particle* particle, real duration)
{
	Vector3 fParticlePos;
	Vector3 fOtherPos;

	particle->getPosition(&fParticlePos);
	other->getPosition(&fOtherPos);

	fParticlePos.addScaledVector(particle->getVelocity(), 2.8);
	fOtherPos.addScaledVector(other->getVelocity(), 2.8);

	//Calculate the vector of the spring
	Vector3 force;
	force = fParticlePos;
	force -= fOtherPos;

	//Calculate the magnitude of the force
	real magnitude = force.magnitude();
	magnitude = real_abs(magnitude - restLength);
	magnitude *= springConstant;

	//Calculate the final force and apply it
	force.normalize();
	force *= -magnitude;
	particle->addForce(force);
}
//End