/*
 *Author: Ian Cubin
 *Date: 12/05/12
 *Description: A dll that parses and returns data from 360voice.com web service
 */
#pragma once

#include "stdafx.h"
#using <mscorlib.dll>
#using <System.dll>
#include "LeaderboardDLL.h"
#include <string>
#include <iostream>

using namespace System;
using namespace System::Net;
using namespace std;

/*A function to convert System::string to standard string*/
void MarshalString ( String ^ s, string& os ) 
{
   using namespace Runtime::InteropServices;
   const char* chars = (const char*)(Marshal::StringToHGlobalAnsi(s)).ToPointer();
   os += chars;
   Marshal::FreeHGlobal(IntPtr((void*)chars));
}

int main(array<System::String ^> ^args)
{
	int exitCode = 1;
	LeaderboardParse::LeaderboardParser myDLLParser;

	while(exitCode >= 1)
	{
		/*Setup web service request URI*/
		string gamerRequest;
		cout << "Enter GamerTag: ";
		cin >> gamerRequest; //get gamertag request from user
		string newRequest = myDLLParser.writeURIRequest(gamerRequest); //API call from dll to set the URI
		String^ uri = gcnew String(newRequest.c_str());

		/*
		 *
		 *The following makes a request to the API for data on the specified gamertag
		 *
		*/

		System::Net::HttpWebRequest^ myRequest = dynamic_cast<HttpWebRequest^>(WebRequest::Create( uri ));
		System::Net::WebResponse^ myResponse = myRequest->GetResponse();

		System::IO::Stream^ ReceiveStream = myResponse->GetResponseStream();

		System::Text::Encoding^ encode = System::Text::Encoding::GetEncoding( "utf-8" );

		System::IO::StreamReader^ readStream = gcnew System::IO::StreamReader( ReceiveStream,encode );
		Console::WriteLine( "\nResponse stream received" );
		array<Char>^ read = gcnew array<Char>(256);

		int count = readStream->Read( read, 0, 256 );

		string requestData;

		while ( count > 0 )
		{
		   String^ str = gcnew String( read,0,count );
		   MarshalString(str, requestData);
		   count = readStream->Read( read, 0, 256 );
		}

		/*
		 *
		 *End data request
		 *
		*/


		/*Use dll to parse and display relevant data*/
		myDLLParser.setData(requestData); //set data from request
		
		if(myDLLParser.doesGamerExist())
		{
			myDLLParser.leaderboard_Data(); //display parsed data
			myDLLParser.getGamerscoreRank();
			myDLLParser.getGamesPlayedRank();
		}

		// Release the resources of stream object.
		readStream->Close();

		// Release the resources of response object.
		myResponse->Close();

		//clear dll data
		myDLLParser.clearData();

		//Replay?
		cout << "0 - Exit / 1 - again: ";
		cin >> exitCode;
		cout << endl;
	}
	
	return 0;
}
