/*
 *Author: Ian Cubin
 *Date: 12/05/12
 *Description: A dll that parses and returns data from 360voice.com web service
 */
#pragma once
#ifdef LEADERBOARDDLL_EXPORTS
#define LEADERBOARDDLL_API __declspec(dllexport) 
#else
#define LEADERBOARDDLL_API __declspec(dllimport) 
#endif

#include <string>
#include <iostream>

using namespace std;

namespace LeaderboardParse
{
	class LeaderboardParser
	{
	public:
		LeaderboardParser() {};
		~LeaderboardParser() {};

		static LEADERBOARDDLL_API std::string writeURIRequest(std::string data);
		LEADERBOARDDLL_API void readXmlData(); //cout xml formatted data
		LEADERBOARDDLL_API void readSortedData(); //cout parsed data
		LEADERBOARDDLL_API void setData(std::string data); //set data to be used
		LEADERBOARDDLL_API void leaderboard_Data(); //cout relevant gamer data
		LEADERBOARDDLL_API void clearData(); //clear data lists
		LEADERBOARDDLL_API void getGamerscoreRank(); //return only Gamerscore rank
		LEADERBOARDDLL_API void getGamesPlayedRank(); //return only Games Played rank 
		LEADERBOARDDLL_API bool doesGamerExist(); //returns whether gamer is in database
	private:
		std::string storedData; //used to store request data
		std::string newData; //parsed data holder
	};
}