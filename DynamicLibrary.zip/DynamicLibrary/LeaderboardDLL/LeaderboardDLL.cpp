/*
 *Author: Ian Cubin
 *Date: 12/05/12
 *Description: A dll that parses and returns data from 360voice.com web service
 */
#pragma once

#include "stdafx.h"
#include "LeaderboardDLL.h"
#include "tinystr.h"
#include "tinyxml.h"
#include <stdexcept>

namespace LeaderboardParse
{
	std::string LeaderboardParser::writeURIRequest(std::string data)
	{
		std::string start = "http://360voice.gamerdna.com/api/gamertag-leaderboard.asp?tag=";
		start += data;
		std::cout << "Making request to: " << start << endl;
		return start;
	}

	void LeaderboardParser::readXmlData()
	{
		cout << storedData << endl;
	}

	void LeaderboardParser::readSortedData()
	{
		cout << newData << endl;
	}

	void LeaderboardParser::setData(std::string data)
	{
		storedData = data;
	}

	void LeaderboardParser::leaderboard_Data()
	{
		newData = "";

		TiXmlDocument doc;
		doc.Parse(storedData.c_str(), 0, TIXML_ENCODING_UTF8);
		TiXmlElement* root = doc.FirstChildElement( "api" );
		TiXmlElement* element = root->FirstChildElement( "info" );

		if(element)
		{
			TiXmlElement* info = element->FirstChildElement( "gamertag" );
			newData += '\n';
			newData += "Gamertag: ";
			newData += info->GetText();
			newData += '\n';

			info = element->FirstChildElement( "score" );
			newData += "GamerScore: ";
			newData += info->GetText();
			newData += '\n';

			info = element->FirstChildElement( "total" );
			newData += "Games Played: ";
			newData += info->GetText();
			newData += '\n';
		}
		else
		{
			newData += "No Data available \n";
		}
		
		element = root->FirstChildElement( "leaderboards" );

		if(element)
		{
			element = element->FirstChildElement( "leaderboard" );
			for(element; element; element = element->NextSiblingElement())
			{
				std::string category = element->Attribute( "name" );

				if(category == "gs")
				{
					TiXmlElement* gamerscore = element->FirstChildElement( "rank" );
					newData += '\n';
					newData += "Top Gamerscores: \n";
					newData += "   Rank: ";
					newData += gamerscore->GetText();
					newData += '\n';

					gamerscore = element->FirstChildElement( "rankchange" );
					newData += "   Change: ";
					newData += gamerscore->GetText();
					newData += '\n';
				}
				else if(category == "mpg")
				{
					TiXmlElement* games = element->FirstChildElement( "rank" );
					newData += '\n';
					newData += "Total Games Played: \n";
					newData += "   Rank: ";
					newData += games->GetText();
					newData += '\n';

					games = element->FirstChildElement( "rankchange" );
					newData += "   Change: ";
					newData += games->GetText();
					newData += '\n';
				}
			}
		}

		cout << newData << endl;
	}

	void LeaderboardParser::clearData()
	{
		storedData = "";
		newData = "";
	}

	void LeaderboardParser::getGamerscoreRank()
	{
		newData = "";

		TiXmlDocument doc;
		doc.Parse(storedData.c_str(), 0, TIXML_ENCODING_UTF8);
		TiXmlElement* root = doc.FirstChildElement( "api" );
		TiXmlElement* element = root->FirstChildElement( "leaderboards" );

		if(element)
		{
			element = element->FirstChildElement( "leaderboard" );
			
			for(element; element; element = element->NextSiblingElement())
			{
				std::string category = element->Attribute( "name" );

				if(category == "gs")
				{
					newData += '\n';
					TiXmlElement* gamerscore = element->FirstChildElement( "rank" );
					newData += "Total Gamerscore Rank: ";
					newData += gamerscore->GetText();
					newData += '\n';
				}
			}
		}

		if(newData == "")
		{
			cout << "An error occured!" << endl;
		}

		cout << newData << endl;
	}

	void LeaderboardParser::getGamesPlayedRank()
	{
		newData = "";

		TiXmlDocument doc;
		doc.Parse(storedData.c_str(), 0, TIXML_ENCODING_UTF8);
		TiXmlElement* root = doc.FirstChildElement( "api" );
		TiXmlElement* element = root->FirstChildElement( "leaderboards" );

		if(element)
		{
			element = element->FirstChildElement( "leaderboard" );
			
			for(element; element; element = element->NextSiblingElement())
			{
				std::string category = element->Attribute( "name" );

				if(category == "mpg")
				{
					newData += '\n';
					TiXmlElement* games = element->FirstChildElement( "rank" );
					newData += "Total Games Played Rank: ";
					newData += games->GetText();
					newData += '\n';
				}
			}
		}

		if(newData == "")
		{
			cout << "An error occured!" << endl;
		}

		cout << newData << endl;
	}

	bool LeaderboardParser::doesGamerExist()
	{
		newData = "";

		TiXmlDocument doc;
		doc.Parse(storedData.c_str(), 0, TIXML_ENCODING_UTF8);
		TiXmlElement* root = doc.FirstChildElement( "api" );
		TiXmlElement* element = root->FirstChildElement( "info" );

		if(element)
		{
			cout <<  endl;
			cout << "Gamer data available!" << endl;
			return true;
		}

		cout << endl;
		cout << "Gamer data not available" << endl;
		cout << endl;
		return false;
	}
}

