/*Author: Ian Cubin
**Date:   01/13/13
**External Resources: Ian Millington
*
*
**Description: This is the start of my physics engine
*/
#pragma once
#include <iostream>
#include <stdlib.h>
#include <math.h>

#ifdef __APPLE__
#include <OpenGL/OpenGL.h>
#include <GLUT/glut.h>
#else
#include <GL/glut.h>	
#endif

#include "imageloader.h" //Provided thanks to OpenGL tutorial
#include "Camera.h"
#include "Particle.h"
#include "timing.h"
#include "ForceGenerator.h"
#include "Vector3.h"

using namespace std;

struct Planets
{
    Particle *particle;
    unsigned startTime;
	real radius;
	Vector3 color;

	void initParticle()
	{
		particle = new Particle();
	}

    /** Draws the round. */
    void render()
    {
        Vector3 position;
        particle->getPosition(&position);

        glColor3f(color.x, color.y, color.z);
        glPushMatrix();
        glTranslatef(position.x, position.y, position.z);
        glutSolidSphere(radius, 150, 150);
        glPopMatrix();

        glColor3f(1.0, 1.0, 1.0);
        glPushMatrix();
        glTranslatef(position.x, 0, position.z);
        glScalef(1.0f, 0.1f, 1.0f);
        glutSolidSphere(radius, 150, 150);
        glPopMatrix();
    }
};

ForceRegistry forceRegister;
CCamera objCamera;

Planets earth;
Planets mars;
Planets sun;
Planets jupiter;
Planets venus;
Planets saturn;
Planets mercury;
Planets uranus;
Planets neptune;

GLuint     _textureId2;           //The id of the background texture
float      xMotion = 0.0f;        //The translation of the camera (x-axis)
float      zMotion = 0.0f;        //The translation of the camera (y-axis)
bool	   fired = false;


const float BOX_SIZE = 7.0f;      //The length of each side of the cube
const float CAMERASPEED = 0.1f;

//Forward declarations
//////////////////////
void loadRoom();
//////////////////////

//Makes the image into a texture, and returns the id of the texture
//Provided thanks to OpenGL tutorial
GLuint loadTexture(Image* image) 
{
	GLuint textureId;
	glGenTextures(1, &textureId);
	glBindTexture(GL_TEXTURE_2D, textureId);
	glTexImage2D(GL_TEXTURE_2D,
				 0,
				 GL_RGB,
				 image->width, image->height,
				 0,
				 GL_RGB,
				 GL_UNSIGNED_BYTE,
				 image->pixels);
	return textureId;
}

//Setup render calls and load images
void initRendering() 
{
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0);
	glEnable(GL_NORMALIZE);
	glEnable(GL_COLOR_MATERIAL);
	glClearColor(0.5f, 0.5f, 0.5f, 1);

	objCamera.Position_Camera(0.0f, 10.0f, 10.0f,	0.0f, 10.0f, 0.0f,   0, 1, 0);

	//Load background texture
	Image* image = loadBMP("space.bmp");
	_textureId2 = loadTexture(image); 
	delete image;
}

//Handles the viewport and projection matrix of the window
void handleResize(int w, int h) 
{
	if (h==0)//Prevent A Divide By Zero By...
	{
		h=1; //Making Height Equal One
	}
	glViewport(0, 0, w, h);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(45.0, (float)w / (float)h, 1.0, 150000000000000.0);
}

//Render the scene
void drawScene() 
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	//Create an ambient light
	GLfloat ambientLight[] = {0.5f, 0.5f, 0.5f, 1.0f};
	glLightModelfv(GL_LIGHT_MODEL_AMBIENT, ambientLight);
	
	GLfloat lightColor[] = {1.0, 1.0, 1.0, 1.0};
	GLfloat lightPos[] = {0.0, 13.0, 0.0}; //Position light 
	glLightfv(GL_LIGHT0, GL_DIFFUSE, lightColor);
	glLightfv(GL_LIGHT0, GL_POSITION, lightPos);

	//Enable and declare texture properties
	glEnable(GL_TEXTURE_2D);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glColor3f(1.0f, 1.0f, 1.0f);

	////////////////////////////////////////////////////////////////////////////////////////////////

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	gluLookAt(objCamera.mPos.x,  objCamera.mPos.y,  objCamera.mPos.z,	
			  objCamera.mView.x, objCamera.mView.y, objCamera.mView.z,	
			  objCamera.mUp.x,   objCamera.mUp.y,   objCamera.mUp.z);

	earth.render();
	mars.render();
	sun.render();
	jupiter.render();
	venus.render();
	saturn.render();
	mercury.render();
	uranus.render();
	neptune.render();

    // Draw some scale lines
    glColor3f(0.75f, 0.75f, 0.75f);
    glBegin(GL_QUADS);
	loadRoom();
    glEnd();
	
	glutSwapBuffers();
}

void Keyboard_Input(unsigned char key, int x, int y)
{
	if((GetKeyState(VK_UP) & 0x80) || (GetKeyState('W') & 0x80))
	{	
		objCamera.Move_Camera( CAMERASPEED);
	}

	if((GetKeyState(VK_DOWN) & 0x80) || (GetKeyState('S') & 0x80))
	{
		objCamera.Move_Camera(-CAMERASPEED);
	}

	if((GetKeyState(VK_LEFT) & 0x80) || (GetKeyState('A') & 0x80))
	{	
		objCamera.Strafe_Camera(-1.0f);
	}

	if((GetKeyState(VK_RIGHT) & 0x80) || (GetKeyState('D') & 0x80))
	{
		objCamera.Strafe_Camera(1.0f);
	}

	if((GetKeyState(VK_ESCAPE) & 0x80))
	{
		exit(0);
	}
}

//Called every time step
void update() 
{
	TimingData::get().update();
	float duration = (float)TimingData::get().lastFrameDuration * 0.0003805;
	if (duration <= 0.0f) 
		return;

	forceRegister.updateForces(duration);

	earth.particle->integrate(duration);
	mars.particle->integrate(duration);
	sun.particle->integrate(duration);
	jupiter.particle->integrate(duration);
	venus.particle->integrate(duration);
	saturn.particle->integrate(duration);
	mercury.particle->integrate(duration);
	uranus.particle->integrate(duration);
	neptune.particle->integrate(duration);

	objCamera.Mouse_Move(0,0, 640, 480);

	glutPostRedisplay();
}

void init()
{
	//init Earth
	earth.initParticle();
	earth.particle->setPosition(0.986, 10.0, 0.0);
	earth.particle->setVelocity(0.0, 0.0, 0.523);
	earth.particle->setMass(1.0);
	earth.startTime = TimingData::get().lastFrameTimestamp;
	earth.radius = 0.1;
	earth.color = Vector3(0.64, 0.74, 0.9);

	//init Mars
	mars.initParticle();
	mars.particle->setPosition(1.382, 10.0, 0.0);
	mars.particle->setVelocity(0.0, 0.0, 0.423);
	mars.particle->setMass(0.10748);
	mars.startTime = TimingData::get().lastFrameTimestamp;
	mars.radius = 0.09;
	mars.color = Vector3(0.9, 0.75, 0.52);

	//init Sun
	sun.initParticle();
	sun.particle->setPosition(0.0, 10.0, 0.0);
	sun.particle->setVelocity(0.0, 0.0, 0.0);
	sun.particle->setMass(332948.6);
	sun.startTime = TimingData::get().lastFrameTimestamp;
	sun.radius = 0.38;
	sun.color = Vector3(1.0, 1.0, 0.0);

	//init Jupiter
	jupiter.initParticle();
	jupiter.particle->setPosition(5.076, 10.0, 0.0);
	jupiter.particle->setVelocity(0.0, 0.0, 0.229);
	jupiter.particle->setMass(317.94);
	jupiter.startTime = TimingData::get().lastFrameTimestamp;
	jupiter.radius = 0.23;
	jupiter.color = Vector3(0.7, 0.64, 0.61);

	//init Venus
	venus.initParticle();
	venus.particle->setPosition(0.7278, 10.0, 0.0);
	venus.particle->setVelocity(0.0, 0.0, 0.615);
	venus.particle->setMass(0.81528);
	venus.startTime = TimingData::get().lastFrameTimestamp;
	venus.radius = 0.05;
	venus.color = Vector3(0.84, 0.83, 0.81);

	//init Saturn
	saturn.initParticle();
	saturn.particle->setPosition(9.818, 10.0, 0.0);
	saturn.particle->setVelocity(0.0, 0.0, 0.169);
	saturn.particle->setMass(95.191);
	saturn.startTime = TimingData::get().lastFrameTimestamp;
	saturn.radius = 0.20;
	saturn.color = Vector3(0.75, 0.72, 0.32);

	//init Mercury
	mercury.initParticle();
	mercury.particle->setPosition(0.346, 10.0, 0.0);
	mercury.particle->setVelocity(0.0, 0.0, 0.832);
	mercury.particle->setMass(5.5773 * pow(10.0, -50));
	mercury.startTime = TimingData::get().lastFrameTimestamp;
	mercury.radius = 0.04;
	mercury.color = Vector3(0.23, 0.21, 0.2);

	//init Uranus
	uranus.initParticle();
	uranus.particle->setPosition(20.07, 10.0, 0.0);
	uranus.particle->setVelocity(0.0, 0.0, 0.119);
	uranus.particle->setMass(14.505);
	uranus.startTime = TimingData::get().lastFrameTimestamp;
	uranus.radius = 0.15;
	uranus.color = Vector3(0.65, 0.75, 0.83);

	neptune.initParticle();
	neptune.particle->setPosition(30.04, 10.0, 0.0);
	neptune.particle->setVelocity(0.0, 0.0, 0.0954);
	neptune.particle->setMass(17.21);
	neptune.startTime = TimingData::get().lastFrameTimestamp;
	neptune.radius = 0.15;
	neptune.color = Vector3(0.56, 0.68, 0.87);
}

void initPlanetaryForces()
{
	ForceGenerator *_earth = new PlanetaryGravity(earth.particle);
	ForceGenerator *_mars = new PlanetaryGravity(mars.particle);
	ForceGenerator *_sun = new PlanetaryGravity(sun.particle);
	ForceGenerator *_jupiter = new PlanetaryGravity(jupiter.particle);
	ForceGenerator *_venus = new PlanetaryGravity(venus.particle);
	ForceGenerator *_saturn = new PlanetaryGravity(saturn.particle);
	ForceGenerator *_uranus = new PlanetaryGravity(uranus.particle);
	ForceGenerator *_mercury = new PlanetaryGravity(mercury.particle);
	ForceGenerator *_neptune = new PlanetaryGravity(neptune.particle);

	//Earth's forces
	forceRegister.add(earth.particle, _mars);
	forceRegister.add(earth.particle, _sun);
	forceRegister.add(earth.particle, _jupiter);
	forceRegister.add(earth.particle, _venus);
	forceRegister.add(earth.particle, _saturn);
	forceRegister.add(earth.particle, _uranus);
	forceRegister.add(earth.particle, _mercury);
	forceRegister.add(earth.particle, _neptune);

	//Mar's forces
	forceRegister.add(mars.particle, _earth);
	forceRegister.add(mars.particle, _sun);
	forceRegister.add(mars.particle, _jupiter);
	forceRegister.add(mars.particle, _venus);
	forceRegister.add(mars.particle, _saturn);
	forceRegister.add(mars.particle, _uranus);
	forceRegister.add(mars.particle, _mercury);
	forceRegister.add(mars.particle, _neptune);

	//Sun's forces
	forceRegister.add(sun.particle, _earth);
	forceRegister.add(sun.particle, _mars);
	forceRegister.add(sun.particle, _jupiter);
	forceRegister.add(sun.particle, _venus);
	forceRegister.add(sun.particle, _saturn);
	forceRegister.add(sun.particle, _uranus);
	forceRegister.add(sun.particle, _mercury);
	forceRegister.add(sun.particle, _neptune);

	//Jupiter's forces
	forceRegister.add(jupiter.particle, _earth);
	forceRegister.add(jupiter.particle, _mars);
	forceRegister.add(jupiter.particle, _sun);
	forceRegister.add(jupiter.particle, _venus);
	forceRegister.add(jupiter.particle, _saturn);
	forceRegister.add(jupiter.particle, _uranus);
	forceRegister.add(jupiter.particle, _mercury);
	forceRegister.add(jupiter.particle, _neptune);

	//Venus's forces
	forceRegister.add(venus.particle, _sun);
	forceRegister.add(venus.particle, _earth);
	forceRegister.add(venus.particle, _mars);
	forceRegister.add(venus.particle, _jupiter);
	forceRegister.add(venus.particle, _saturn);
	forceRegister.add(venus.particle, _uranus);
	forceRegister.add(venus.particle, _mercury);
	forceRegister.add(venus.particle, _neptune);

	//Saturn's forces
	forceRegister.add(saturn.particle, _sun);
	forceRegister.add(saturn.particle, _earth);
	forceRegister.add(saturn.particle, _mars);
	forceRegister.add(saturn.particle, _jupiter);
	forceRegister.add(saturn.particle, _venus);
	forceRegister.add(saturn.particle, _uranus);
	forceRegister.add(saturn.particle, _mercury);
	forceRegister.add(saturn.particle, _neptune);

	//Uranus' forces
	forceRegister.add(uranus.particle, _sun);
	forceRegister.add(uranus.particle, _earth);
	forceRegister.add(uranus.particle, _mars);
	forceRegister.add(uranus.particle, _jupiter);
	forceRegister.add(uranus.particle, _venus);
	forceRegister.add(uranus.particle, _saturn);
	forceRegister.add(uranus.particle, _mercury);
	forceRegister.add(uranus.particle, _neptune);

	//Mercury's forces
	forceRegister.add(mercury.particle, _sun);
	forceRegister.add(mercury.particle, _earth);
	forceRegister.add(mercury.particle, _mars);
	forceRegister.add(mercury.particle, _jupiter);
	forceRegister.add(mercury.particle, _venus);
	forceRegister.add(mercury.particle, _saturn);
	forceRegister.add(mercury.particle, _uranus);
	forceRegister.add(mercury.particle, _neptune);

	//Neptune's forces
	forceRegister.add(neptune.particle, _sun);
	forceRegister.add(neptune.particle, _earth);
	forceRegister.add(neptune.particle, _mars);
	forceRegister.add(neptune.particle, _jupiter);
	forceRegister.add(neptune.particle, _venus);
	forceRegister.add(neptune.particle, _saturn);
	forceRegister.add(neptune.particle, _uranus);
	forceRegister.add(neptune.particle, _mercury);
}

int main(int argc, char** argv) 
{
	glutInit(&argc, argv);
	TimingData::init();
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
	glutInitWindowSize(1280, 720);
	
	glutCreateWindow("Planetary Motion");

	init();
	initPlanetaryForces();

	initRendering();
	
	glutDisplayFunc(drawScene);
	glutKeyboardFunc(Keyboard_Input);
	glutReshapeFunc(handleResize);
	glutIdleFunc(update);
	
	glutMainLoop();
	TimingData::deinit();
	return 0;
}


//Creates the background vertices and texture coordinates
void loadRoom()
{
	//Top Face
	glNormal3f(0.0, 1.0f, 0.0f);
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(-BOX_SIZE*(25), BOX_SIZE*(25), -BOX_SIZE*(25));
	glTexCoord2f(1.0f, 0.0f);
	glVertex3f(-BOX_SIZE*(25), BOX_SIZE*(25), BOX_SIZE*(25));
	glTexCoord2f(1.0f, 1.0f);
	glVertex3f(BOX_SIZE*(25), BOX_SIZE*(25), BOX_SIZE*(25));
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(BOX_SIZE*(25), BOX_SIZE*(25), -BOX_SIZE*(25));

	//Bottom Face
	glNormal3f(0.0, -1.0f, 0.0f);
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(-BOX_SIZE*(25), -BOX_SIZE*(25), -BOX_SIZE*(25));
	glTexCoord2f(1.0f, 0.0f);
	glVertex3f(BOX_SIZE*(25), -BOX_SIZE*(25), -BOX_SIZE*(25));
	glTexCoord2f(1.0f, 1.0f);
	glVertex3f(BOX_SIZE*(25), -BOX_SIZE*(25), BOX_SIZE*(25));
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(-BOX_SIZE*(25), -BOX_SIZE*(25), BOX_SIZE*(25));

	//Back Face
	glNormal3f(0.0, 1.0f, 0.0f);
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(-BOX_SIZE*(25), -BOX_SIZE*(25), -BOX_SIZE*(25));
	glTexCoord2f(1.0f, 0.0f);
	glVertex3f(-BOX_SIZE*(25), BOX_SIZE*(25), -BOX_SIZE*(25));
	glTexCoord2f(1.0f, 1.0f);
	glVertex3f(BOX_SIZE*(25), BOX_SIZE*(25), -BOX_SIZE*(25));
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(BOX_SIZE*(25), -BOX_SIZE*(25), -BOX_SIZE*(25));

	//Front face
	glNormal3f(0.0, 0.0f, 1.0f);
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(-BOX_SIZE*(25), -BOX_SIZE*(25), BOX_SIZE*(25));
	glTexCoord2f(1.0f, 0.0f);
	glVertex3f(BOX_SIZE*(25), -BOX_SIZE*(25), BOX_SIZE*(25));
	glTexCoord2f(1.0f, 1.0f);
	glVertex3f(BOX_SIZE*(25), BOX_SIZE*(25), BOX_SIZE*(25));
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(-BOX_SIZE*(25), BOX_SIZE*(25), BOX_SIZE*(25));

	//Left face
	glNormal3f(-1.0, 0.0f, 0.0f);
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(-BOX_SIZE*(25), -BOX_SIZE*(25), -BOX_SIZE*(25));
	glTexCoord2f(1.0f, 0.0f);
	glVertex3f(-BOX_SIZE*(25), -BOX_SIZE*(25), BOX_SIZE*(25));
	glTexCoord2f(1.0f, 1.0f);
	glVertex3f(-BOX_SIZE*(25), BOX_SIZE*(25), BOX_SIZE*(25));
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(-BOX_SIZE*(25), BOX_SIZE*(25), -BOX_SIZE*(25));

	//Right Face
	glNormal3f(1.0, 0.0f, 0.0f);
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(BOX_SIZE*(25), -BOX_SIZE*(25), -BOX_SIZE*(25));
	glTexCoord2f(1.0f, 0.0f);
	glVertex3f(BOX_SIZE*(25), BOX_SIZE*(25), -BOX_SIZE*(25));
	glTexCoord2f(1.0f, 1.0f);
	glVertex3f(BOX_SIZE*(25), BOX_SIZE*(25), BOX_SIZE*(25));
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(BOX_SIZE*(25), -BOX_SIZE*(25), BOX_SIZE*(25));
}









