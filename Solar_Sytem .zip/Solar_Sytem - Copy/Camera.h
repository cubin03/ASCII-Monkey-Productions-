#pragma once
#include <GL/glut.h>
#include <math.h>
#include "Vector3.h"

class CCamera 
{
public:

	Vector3 mPos;	
	Vector3 mView;		
	Vector3 mUp;			

	// This function lets you control the camera with the mouse
	void Mouse_Move(int x, int y, int wndWidth, int wndHeight);

	void Move_Camera(float speed);
	void Strafe_Camera(float speed);
	void Rotate_View(float speed);
	void Position_Camera(float pos_x, float pos_y,float pos_z,
			 			 float view_x, float view_y, float view_z,
						 float up_x,   float up_y,   float up_z);
};