#pragma once
#include "Vector3.h"

//Flips all the components of the vector
void Vector3::invert()
{
	x = -x;
	y = -y;
	z = -z;
}

//return magnitude of this vector
real Vector3::magnitude() const
{
	return sqrt(x*x+y*y+z*z);
}

//return square of this vector
real Vector3::squareMagnitude() const
{
	return x*x+y*y+z*z;
}

//turns a non-zero vector into a unit vector
void Vector3::normalize()
{
	real l = magnitude();
	if(l > 0)
	{
		(*this) *= ((real)1)/l;
	}
}

//multiply this vector by a scalar
void Vector3::operator*=(const real value)
{
	x *= value;
	y *= value;
	z *= value;
}

//returns a copy of this vector scaled by value
Vector3 Vector3::operator*(const real value) const
{
	return Vector3(x*value, y*value, z*value);
}

//Adds the given vector to this
void Vector3::operator+=(const Vector3 &v)
{
	x += v.x;
	y += v.y;
	z += v.z;
}

//returns value of given vector added to this
Vector3 Vector3::operator+(const Vector3 &v) const
{
	return Vector3(x+v.x, y+v.y, z+v.z);
}

//subtracts the given vector to this
void Vector3::operator-=(const Vector3 &v)
{
	x -= v.x;
    y -= v.y;
    z -= v.z;
}

//returns value of given vector subtracted from this
Vector3 Vector3::operator-(const Vector3 &v) const
{
	return Vector3(x-v.x, y-v.y, z-v.z);
}

//Adds the given vector to this, scaled by given amount
void Vector3::addScaledVector(const Vector3 &vector, real scale)
{
	x += vector.x * scale;
    y += vector.y * scale;
    z += vector.z * scale;
}

//Calculates & returns component-wise product of this vector with given vector
Vector3 Vector3::componentProduct(const Vector3 &vector) const
{
	return Vector3(x * vector.x, y * vector.y, z * vector.z);
}

//Performs component-wise product with given vector and sets this vector to its result
void Vector3::componentProductUpdate(const Vector3 &vector)
{
	x *= vector.x;
    y *= vector.y;
    z *= vector.z;
}

//calculates & returns scalar product of this vector with given vector
real Vector3::operator*(const Vector3 &vector) const
{
	return x*vector.x + y*vector.y + z*vector.z;
}

//calculate & returns vector product of this vector with a given vector
//LONG-HAND version of following overloaded operators
Vector3 Vector3::vectorProduct(const Vector3 &vector) const
{
	return Vector3(y*vector.z - z*vector.y,
				   z*vector.x - x*vector.z,
				   x*vector.y - y*vector.x);
}

//updates this vector to be the vector product of it and a given vector
void Vector3::operator%=(const Vector3 &vector)
{
	*this = vectorProduct(vector); 
}

//calculate & returns vector product of this vector with a given vector
Vector3 Vector3::operator%(const Vector3 &vector) const
{
	return Vector3(y*vector.z - z*vector.y,
				   z*vector.x - x*vector.z,
				   x*vector.y - y*vector.x);
}

//generates a orthonormal basis from two given axis
void Vector3::makeOrthonormalBasis(Vector3 *a, Vector3 *b, Vector3 *c)
{
	a->normalize();
	(*c) = (*a) % (*b);
	if(c->squareMagnitude() == 0.0) return; //or generate an error
	c->normalize();
	(*b) = (*c) % (*a);
}

//reset all values
void Vector3::clear()
{
    x = y = z = 0;
}
