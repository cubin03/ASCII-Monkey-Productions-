#pragma once
#include "ForceGenerator.h"

void ForceRegistry::updateForces(real duration)
{
	Registry::iterator i = registrations.begin();
	for(; i != registrations.end(); i++)
	{
		i->forceGen->updateForce(i->particle, duration);
	}
}

void ForceRegistry::add(Particle* particle, ForceGenerator *fg)
{
	ForceRegistry::ForceRegistration registration;
	registration.particle = particle;
	registration.forceGen = fg;
	registrations.push_back(registration);
}

ParticleGravity::ParticleGravity(const Vector3& gravity)
:gravity(gravity)
{
}

void ParticleGravity::updateForce(Particle* particle, real duration)
{
	if(!particle->hasFiniteMass()) return;

	particle->addForce(gravity * particle->getMass());
}

PlanetaryGravity::PlanetaryGravity(Particle* particle)
:planet(particle)
{
}

void PlanetaryGravity::updateForce(Particle* particle, real duration)
{
	Vector3 vDistance = planet->getPosition() - particle->getPosition();
	real distance = vDistance.squareMagnitude();

	real combinedMass = particle->getMass() * planet->getMass();
	vDistance.normalize();
	Vector3 force = vDistance * ((0.9 * pow(10.0, -6)) * (combinedMass / distance));
	particle->addForce(force);
}