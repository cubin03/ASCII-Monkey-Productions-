#pragma once
#include "Vector3.h"
#include "Particle.h"
#include <vector>
#include <math.h>

class ForceGenerator
{
public:

	//update forces on a given particle
	virtual void updateForce(Particle *particle, real duration) = 0;
};

class ForceRegistry
{
protected:

	//keeps track of a particle and its force generator
	struct ForceRegistration
	{
		Particle *particle;
		ForceGenerator *forceGen;
	};

	//hold list of force registrations
	typedef std::vector<ForceRegistration> Registry;
	Registry registrations;

public:

	//Register the force with a particle
	void add(Particle* particle, ForceGenerator *fg);

	//removes a registration from the registry
	//void remove(Particle* particle, ForceGenerator *fg);

	//clear all registrations
	//void clear();

	//calls all the force generators to update forces
	void updateForces(real duration);
};

class ParticleGravity:public ForceGenerator
{
	Vector3 gravity;

public:
	ParticleGravity(const Vector3 &gravity);

	virtual void updateForce(Particle *particle, real duration);

};

class PlanetaryGravity:public ForceGenerator
{
	Particle *planet;

public:
	PlanetaryGravity(Particle *planet);

	virtual void updateForce(Particle *obj1, real duration);
};