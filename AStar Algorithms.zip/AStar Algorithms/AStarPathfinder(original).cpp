/*
Author: Ian Cubin 
Description: A pathfinding algorithm that implements A*

Certification of Authenticity: 
I certify that this assignment is entirely my own work.
*/

#pragma once

#include "AStarPathfinder.h"
#include "Node.h"
#include "Connection.h"
#include "GridGraph.h"
#include "Game.h"
#include "Path.h"
#include "EuclideanHeuristic.h"
#include <algorithm>
#include <PerformanceTracker.h>
#include "Vector2D.h"
#include "Grid.h"

AStarPathfinder::AStarPathfinder( Graph* pGraph, Grid* grid )
:GridPathfinder(dynamic_cast<GridGraph*>(pGraph) )
,mpStartRecorder(NULL)
,mpEndRecorder(NULL)
,mpCurrentRecorder(NULL)
{
#ifdef VISUALIZE_PATH
	mpPath = NULL;
#endif

	for (int i = 0; i < pGraph->getNodeCount(); i++)
	{
		AStarNodeRecorder* pNodeRecord = new AStarNodeRecorder();
		pNodeRecord->sNode = pGraph->getNode(i);
		pNodeRecord->sPosition = grid->getULCornerOfSquare(i);
		pNodeRecord->init();
		vNodeRecorders.push_back(pNodeRecord);
	}
}

AStarPathfinder::~AStarPathfinder()
{
#ifdef VISUALIZE_PATH
	delete mpPath;
#endif

	for (unsigned int i = 0; i < vNodeRecorders.size(); i++)
	{
		delete vNodeRecorders[i];
	}

	vNodeRecorders.clear();
}

bool AStarPathfinder::doesContain(bool open, Node* node)
{
	if(open)
	{
		for(int i = 0; i < (int)vOpenList.size(); i++)
		{
			if(node == vOpenList[i]->sNode)
			{
				return true;
			}
		}
	}
	else
	{
		for(int i = 0; i < (int)vCloseList.size(); i++)
		{
			if(node == vCloseList[i]->sNode)
			{
				return true;
			}
		}
	}

	return false;
}

AStarNodeRecorder* AStarPathfinder::findByNode(bool open, Node* node)
{
	if(open)
	{
		for(int i = 0; i < (int)vOpenList.size(); i++)
		{
			if(node == vOpenList[i]->sNode)
			{
				return vOpenList[i];
			}
		}
	}
	else
	{
		for(int i = 0; i < (int)vCloseList.size(); i++)
		{
			if(node == vCloseList[i]->sNode)
			{
				return vCloseList[i];
			}
		}
	}

	return NULL;
}

void AStarPathfinder::removeNode(bool open, Node* node)
{
	if(open)
	{
		for(int i = 0; i < (int)vOpenList.size(); i++)
		{
			if(node == vOpenList[i]->sNode)
			{
				vOpenList.erase(vOpenList.begin() + i);
				return;
			}
		}
	}
	else
	{
		for(int i = 0; i < (int)vCloseList.size(); i++)
		{
			if(node == vCloseList[i]->sNode)
			{
				vCloseList.erase(vCloseList.begin() + i);
				return;
			}
		}
	}
}

Path* AStarPathfinder::findPath(Node* pFrom, Node* pTo)
{
	gpPerformanceTracker->clearTracker("path");
	gpPerformanceTracker->startTracking("path");

#ifdef VISUALIZE_PATH
	delete mpPath;
	mVisitedNodes.clear();
	mVisitedNodes.push_back( pFrom );
#endif

	for (unsigned int i = 0; i < vNodeRecorders.size(); i++)
	{
		vNodeRecorders[i]->init();
	}

	Path* pPath = new Path();

	mpStartRecorder = new AStarNodeRecorder();
	mpEndRecorder = new AStarNodeRecorder();
	mpCurrentRecorder = new AStarNodeRecorder();
	mpHeuristic = new EuclideanHeuristic(NULL);

	float endNodeHeuristic = 0.0f;

	mpStartRecorder->sNode = pFrom;
	mpHeuristic->setGoal(mpStartRecorder);
	mpStartRecorder->sConnection = NULL;
	mpStartRecorder->sCostSoFar = 0;
	mpStartRecorder->sEstimatedTotalCost = mpHeuristic->estimateDistance(mpStartRecorder);

	vOpenList.clear();
	vOpenList.push_back(mpStartRecorder);
	vCloseList.clear();

	while( vOpenList.size() > 0 )
	{
		int smallestCostIndex = 0;
		float smallestCost;

		for(int i = 0; i < (int)vOpenList.size(); i++)
		{
			if(smallestCost = 0)
			{
				smallestCost = vOpenList[i]->sEstimatedTotalCost;
				smallestCostIndex = i;
			}
			else if(vOpenList[i]->sCostSoFar < smallestCost)
			{
				smallestCost = vOpenList[i]->sEstimatedTotalCost;
				smallestCostIndex = i;
			}
		}

		mpCurrentRecorder = vOpenList[smallestCostIndex];

		if(mpCurrentRecorder->sNode == pTo)
		{
			break;
		}

		std::vector<Connection*> connections = mpGraph->getConnections( mpCurrentRecorder->sNode->getId() );

		for(int j = 0; j < (int)connections.size(); j++)
		{
			Node* endNode = connections[j]->getToNode();
			float endNodeCost = mpCurrentRecorder->sCostSoFar + connections[j]->getCost();

			if(doesContain(false, endNode))
			{
				mpEndRecorder = findByNode(false, endNode);

				if(mpEndRecorder->sCostSoFar <= endNodeCost)
				{
					continue;
				}

				removeNode(false, mpEndRecorder->sNode);
				endNodeHeuristic = mpEndRecorder->sCost - mpEndRecorder->sCostSoFar;
			}
			else if(doesContain(true, endNode))
			{
				mpEndRecorder = findByNode(true, endNode);

				if(mpEndRecorder->sCostSoFar <= endNodeCost)
				{
					continue;
				}

				endNodeHeuristic = mpEndRecorder->sCost - mpEndRecorder->sCostSoFar;
			}
			else
			{
				mpEndRecorder = vNodeRecorders[endNode->getId()];
				endNodeHeuristic = mpHeuristic->estimateDistance(mpEndRecorder);
			}

			mpEndRecorder->sCost = endNodeCost;
			mpEndRecorder->sConnection = connections[j];
			mpEndRecorder->sEstimatedTotalCost = mpEndRecorder->sCost + endNodeHeuristic;

			if(!doesContain(true, endNode))
			{
				vOpenList.push_back(mpEndRecorder);
#ifdef VISUALIZE_PATH
				mVisitedNodes.push_back(mpEndRecorder->sNode);
#endif
			}
		}

		removeNode(true, mpCurrentRecorder->sNode);
		vCloseList.push_back(mpCurrentRecorder);
	}

	if (mpCurrentRecorder != NULL && mpCurrentRecorder->sNode == pTo)
	{
		while (mpCurrentRecorder->sNode != pFrom)
		{
			pPath->addNode(mpCurrentRecorder->sNode);

			if (mpCurrentRecorder->sConnection != NULL)
			{
				mpCurrentRecorder = vNodeRecorders[mpCurrentRecorder->sConnection->getFromNode()->getId()];
			}
			else
			{
				break;
			}
		}

		pPath->addNode(pFrom);
		pPath->reverseNodes();
	}
	else
	{
		// no path found; add start and end nodes
		pPath->addNode(pFrom);
		pPath->addNode(pTo);
	}

	gpPerformanceTracker->stopTracking("path");
	mTimeElapsed = gpPerformanceTracker->getElapsedTime("path");

#ifdef VISUALIZE_PATH
	mpPath = pPath;
#endif

	return pPath;
}