/*
Author: Ian Cubin 
Description: A pathfinding algorithm that implements A*

Certification of Authenticity: 
I certify that this assignment is entirely my own work.
*/

#pragma once

#include "GridPathfinder.h"
#include "Vector2D.h"
#include <vector>

class Node;
class Connection;
class EuclideanHeuristic;
class Grid;

struct AStarNodeRecorder
{
	Node* sNode;
	Connection* sConnection;
	float sCost;
	float sCostSoFar;
	float sEstimatedTotalCost;
	Vector2D sPosition;

	void init()
	{
		sPosition = Vector2D(0, 0);
		sConnection = NULL;
		sCost = 0.0f;
		sCostSoFar = 0.0f;
		sEstimatedTotalCost = 0.0f;
	}
};

class AStarPathfinder:public GridPathfinder
{
public:
	AStarPathfinder( Graph* pGraph, Grid* grid );
	~AStarPathfinder();

	bool doesContain(bool open, Node* node);
	AStarNodeRecorder* findByNode(bool open, Node* node);
	void removeNode(bool open, Node* node);

	Path* findPath( Node* pFrom, Node* pTo );

private:
	std::vector<AStarNodeRecorder*> vOpenList;
	std::vector<AStarNodeRecorder*> vCloseList;
	std::vector<AStarNodeRecorder*> vNodeRecorders;

	AStarNodeRecorder* mpStartRecorder;
	AStarNodeRecorder* mpEndRecorder;
	AStarNodeRecorder* mpCurrentRecorder;

	EuclideanHeuristic* mpHeuristic;
};