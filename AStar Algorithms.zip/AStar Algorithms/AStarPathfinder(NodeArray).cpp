/*
Author: Ian Cubin 
Description: A pathfinding algorithm that implements A* (this uses the Node Array A* technique)

Certification of Authenticity: 
I certify that this assignment is entirely my own work.
*/

#pragma once

#include "AStarPathfinder.h"
#include "Node.h"
#include "Connection.h"
#include "GridGraph.h"
#include "Game.h"
#include "Path.h"
#include "FryHeuristic.h"
#include <algorithm>
#include <PerformanceTracker.h>
#include "Vector2D.h"
#include "Grid.h"

AStarPathfinder::AStarPathfinder( Graph* pGraph, Grid* grid )
:GridPathfinder(dynamic_cast<GridGraph*>(pGraph) )
,mpStartRecorder(NULL)
,mpCurrentRecorder(NULL)
,mpGrid(grid)
{
#ifdef VISUALIZE_PATH
	mpPath = NULL;
#endif

	//create list that contains all the nodes in the graph
	for (int i = 0; i < pGraph->getNodeCount(); i++)
	{
		AStarNodeRecorder* pNodeRecord = new AStarNodeRecorder();
		pNodeRecord->sNode = pGraph->getNode(i);
		pNodeRecord->sPosition = grid->getULCornerOfSquare(i);
		pNodeRecord->init(); //init them all as unvisited
		mvNodeRecorders.push_back(pNodeRecord);
	}
}

AStarPathfinder::~AStarPathfinder()
{
#ifdef VISUALIZE_PATH
	delete mpPath;
#endif

	for (unsigned int i = 0; i < mvNodeRecorders.size(); i++)
	{
		delete mvNodeRecorders[i];
	}

	mvNodeRecorders.clear();
}

bool AStarPathfinder::doesContain(bool open, Node* node)
{
	if(open)
	{
		for(int i = 0; i < (int)mvOpenList.size(); i++)
		{
			if(node == mvOpenList[i]->sNode)
			{
				return true;
			}
		}
	}

	return false;
}

void AStarPathfinder::removeNode(bool open, Node* node)
{
	if(open)
	{
		for(int i = 0; i < (int)mvOpenList.size(); i++)
		{
			if(node == mvOpenList[i]->sNode)
			{
				mvOpenList.erase(mvOpenList.begin() + i);
				return;
			}
		}
	}
}

Path* AStarPathfinder::findPath(Node* pFrom, Node* pTo)
{
	gpPerformanceTracker->clearTracker("path");
	gpPerformanceTracker->startTracking("path");

#ifdef VISUALIZE_PATH
	delete mpPath;
	mVisitedNodes.clear();
	mVisitedNodes.push_back( pFrom );
#endif

	for (unsigned int i = 0; i < mvNodeRecorders.size(); i++)
	{
		mvNodeRecorders[i]->init();
	}

	Path* pPath = new Path();

	mpStartRecorder = new AStarNodeRecorder();
	AStarNodeRecorder* endRecord;
	mpCurrentRecorder = new AStarNodeRecorder();
	mpHeuristic = new FryHeuristic(NULL);

	float endNodeHeuristic = 0.0f;

	mpStartRecorder->sNode = pFrom;
	mpHeuristic->setGrid(mpGrid);
	mpStartRecorder->sConnection = NULL;
	mpStartRecorder->sCostSoFar = 0;
	mpStartRecorder->sEstimatedTotalCost = (float)mpHeuristic->estimateDistance(pTo, mpStartRecorder->sNode);

	mvOpenList.clear();
	mvOpenList.push_back(mpStartRecorder);

	while( mvOpenList.size() > 0 )
	{
		int smallestCostIndex = 0;
		float smallestCost;

		//still need open list for sole purpose of finding smallest cost
		for(int i = 0; i < (int)mvOpenList.size(); i++)
		{
			if(smallestCost = 0)
			{
				smallestCost = mvOpenList[i]->sEstimatedTotalCost;
				smallestCostIndex = i;
			}
			else if(mvOpenList[i]->sCostSoFar < smallestCost)
			{
				smallestCost = mvOpenList[i]->sEstimatedTotalCost;
				smallestCostIndex = i;
			}
		}

		mpCurrentRecorder = mvOpenList[smallestCostIndex];

		if(mpCurrentRecorder->sNode == pTo)
		{
			break;
		}

		std::vector<Connection*> connections = mpGraph->getConnections( mpCurrentRecorder->sNode->getId() );

		for(int j = 0; j < (int)connections.size(); j++)
		{
			endRecord = mvNodeRecorders[connections[j]->getToNode()->getId()];

			float endNodeCost = mpCurrentRecorder->sCostSoFar + connections[j]->getCost();

			if(endRecord->category == CLOSE) //check if node is closed rather than search close list
			{
				if(endRecord->sCostSoFar <= endNodeCost)
				{
					continue;
				}

				endRecord->category = REMOVED; //remove when node is no longer needed
				endNodeHeuristic = endRecord->sCost - endRecord->sCostSoFar;
			}
			else if(endRecord->category == OPEN) //check if node is open
			{
				if(endRecord->sCostSoFar <= endNodeCost)
				{
					continue;
				}

				endNodeHeuristic = endRecord->sCost - endRecord->sCostSoFar;
			}
			else if(endRecord->category == UNVISITED) //otherwise node is unvisited
			{
				endNodeHeuristic = (float)mpHeuristic->estimateDistance(pTo, endRecord->sNode);
			}

			endRecord->sCost = endNodeCost;
			endRecord->sConnection = connections[j];
			endRecord->sEstimatedTotalCost = endRecord->sCost + endNodeHeuristic;

			if(!doesContain(true, endRecord->sNode))
			{
				mvOpenList.push_back(endRecord);
				endRecord->category = OPEN; //change node to open
#ifdef VISUALIZE_PATH
				mVisitedNodes.push_back(endRecord->sNode);
#endif
			}
		}

		removeNode(true, mpCurrentRecorder->sNode);
		mpCurrentRecorder->category = CLOSE; //change node to closed
	}

	if (mpCurrentRecorder != NULL && mpCurrentRecorder->sNode == pTo)
	{
		while (mpCurrentRecorder->sNode != pFrom)
		{
			pPath->addNode(mpCurrentRecorder->sNode);

			if (mpCurrentRecorder->sConnection != NULL)
			{
				mpCurrentRecorder = mvNodeRecorders[mpCurrentRecorder->sConnection->getFromNode()->getId()];
			}
			else
			{
				break;
			}
		}

		pPath->addNode(pFrom);
		pPath->reverseNodes();
	}
	else
	{
		pPath->addNode(pFrom);
		pPath->addNode(pTo);
	}

	gpPerformanceTracker->stopTracking("path");
	mTimeElapsed = gpPerformanceTracker->getElapsedTime("path");

#ifdef VISUALIZE_PATH
	mpPath = pPath;
#endif

	return pPath;
}