/*
Author: Ian Cubin 
Description: A pathfinding algorithm that implements A* (this uses the Node Array A* technique)

Certification of Authenticity: 
I certify that this assignment is entirely my own work.
*/

#pragma once

#include "GridPathfinder.h"
#include "Vector2D.h"
#include <vector>

class Node;
class Connection;
class FryHeuristic;
class Grid;

enum LISTING
{
	UNVISITED = 0,
	OPEN,
	CLOSE,
	REMOVED
};

struct AStarNodeRecorder
{
	Node* sNode;
	Connection* sConnection;
	float sCost;
	float sCostSoFar;
	float sEstimatedTotalCost;
	Vector2D sPosition;
	LISTING category;

	void init()
	{
		sPosition = Vector2D(0, 0);
		sConnection = NULL;
		sCost = 0.0f;
		sCostSoFar = 0.0f;
		sEstimatedTotalCost = 0.0f;
		category = UNVISITED;
	}
};

class AStarPathfinder:public GridPathfinder
{
public:
	AStarPathfinder( Graph* pGraph, Grid* grid );
	~AStarPathfinder();

	bool doesContain(bool open, Node* node);
	void removeNode(bool open, Node* node);

	Path* findPath( Node* pFrom, Node* pTo );

private:
	std::vector<AStarNodeRecorder*> mvOpenList;
	std::vector<AStarNodeRecorder*> mvNodeRecorders; //A* Node Array

	AStarNodeRecorder* mpStartRecorder;
	AStarNodeRecorder* mpCurrentRecorder;

	FryHeuristic* mpHeuristic;
	Grid* mpGrid;
};